import 'dotenv/config';
import express from 'express';
import pb from '../utils/pocketbaseClient.js';
import logger from '../utils/logger.js';

const router = express.Router();

// POST /webhooks/bling - Handle Bling webhook events
router.post('/bling', async (req, res) => {
  const { numero_pedido, danfe_url, codigo_rastreio } = req.body;

  if (!numero_pedido) {
    throw new Error('Campo obrigatório: numero_pedido');
  }

  // Find pedido by numero_pedido
  const pedidos = await pb.collection('pedidos').getFullList({
    filter: `numero_pedido = "${numero_pedido}"`,
  });

  if (pedidos.length === 0) {
    throw new Error(`Pedido com número ${numero_pedido} não encontrado`);
  }

  const pedido = pedidos[0];
  const updateData = {};

  if (danfe_url) {
    updateData.danfe_url = danfe_url;
  }

  if (codigo_rastreio) {
    updateData.codigo_rastreio = codigo_rastreio;
    updateData.status = 'enviado';

    // Update historico_status
    const novoHistorico = pedido.historico_status || [];
    novoHistorico.push({
      status: 'enviado',
      timestamp: new Date().toISOString(),
    });
    updateData.historico_status = novoHistorico;
  }

  await pb.collection('pedidos').update(pedido.id, updateData);

  logger.info(`Webhook Bling processado: numero_pedido=${numero_pedido}, danfe_url=${danfe_url}, codigo_rastreio=${codigo_rastreio}`);

  res.json({
    sucesso: true,
    mensagem: 'Webhook Bling processado com sucesso',
  });
});

// POST /webhooks/stripe - Handle Stripe webhook events
router.post('/stripe', async (req, res) => {
  // Placeholder for Stripe webhook implementation
  logger.info('Webhook Stripe recebido');

  res.json({
    message: 'Stripe webhook received',
  });
});

// POST /webhooks/melhorenvio - Handle Melhor Envio webhook events
router.post('/melhorenvio', async (req, res) => {
  // Placeholder for Melhor Envio webhook implementation
  logger.info('Webhook Melhor Envio recebido');

  res.json({
    message: 'Melhor Envio webhook received',
  });
});

export default router;