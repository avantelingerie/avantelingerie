import 'dotenv/config';
import express from 'express';
import axios from 'axios';
import pb from '../utils/pocketbaseClient.js';
import logger from '../utils/logger.js';

const router = express.Router();

const handleBlingAuth = async (req, res) => {
  const { code } = req.query;

  if (!code) {
    return res.status(400).json({ erro: true, mensagem: 'Code não fornecido na query string' });
  }

  const clientId = process.env.BLING_CLIENT_ID;
  const clientSecret = process.env.BLING_CLIENT_SECRET;
  const redirectUri = process.env.BLING_REDIRECT_URI;

  if (!clientId || !clientSecret || !redirectUri) {
    throw new Error('Variáveis de ambiente do Bling não configuradas');
  }

  const credentials = Buffer.from(`${clientId}:${clientSecret}`).toString('base64');

  const response = await axios.post(
    'https://www.bling.com.br/Api/v3/oauth/token',
    new URLSearchParams({
      grant_type: 'authorization_code',
      code,
      redirect_uri: redirectUri,
    }),
    {
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Authorization': `Basic ${credentials}`,
      },
    }
  );

  if (!response.data || !response.data.access_token) {
    throw new Error('Resposta inválida do Bling: access_token não encontrado');
  }

  const { access_token, refresh_token, expires_in } = response.data;

  const savedRecord = await pb.collection('bling_tokens').create({
    access_token,
    refresh_token,
    expires_in,
  });

  logger.info(`Token Bling salvo com sucesso: ${savedRecord.id}`);

  res.status(200).json({
    sucesso: true,
    mensagem: 'Autenticação com Bling realizada com sucesso',
    tokens: {
      access_token,
      refresh_token,
      expires_in,
    },
    record_id: savedRecord.id,
  });
};

const sincronizarEstoque = async (req, res) => {
  const { sku, quantidade_atual } = req.body;

  // Input validation - throw Error so errorMiddleware catches it
  if (!sku) {
    throw new Error('Campo "sku" é obrigatório');
  }

  if (quantidade_atual === undefined || quantidade_atual === null) {
    throw new Error('Campo "quantidade_atual" é obrigatório');
  }

  if (typeof quantidade_atual !== 'number' || quantidade_atual < 0) {
    throw new Error('Campo "quantidade_atual" deve ser um número não-negativo');
  }

  const blingApiToken = process.env.BLING_API_TOKEN;

  if (!blingApiToken) {
    throw new Error('BLING_API_TOKEN não configurado nas variáveis de ambiente');
  }

  try {
    // Step 1: Query PocketBase variacoes collection by sku field to get produto_id
    let variacao;
    try {
      const variacoes = await pb.collection('variacoes').getFullList({
        filter: `sku = "${sku}"`,
      });

      if (!variacoes || variacoes.length === 0) {
        return res.status(200).json({
          sucesso: false,
          erro: `SKU "${sku}" não encontrado na base de dados`,
        });
      }

      variacao = variacoes[0];
    } catch (pbError) {
      logger.error(`Erro ao consultar PocketBase: ${pbError.message}`);
      return res.status(200).json({
        sucesso: false,
        erro: 'Erro ao consultar base de dados de variações',
      });
    }

    const produtoId = variacao.produto_id;

    if (!produtoId) {
      return res.status(200).json({
        sucesso: false,
        erro: `Variação com SKU "${sku}" não possui produto_id associado`,
      });
    }

    // Step 2: Query Bling API GET /produtos/{id} to get estoque ID
    let estoqueId;
    try {
      const produtoResponse = await axios.get(
        `https://bling.com.br/api/v3/produtos/${produtoId}`,
        {
          headers: {
            'Authorization': `Bearer ${blingApiToken}`,
            'Accept': 'application/json',
          },
        }
      );

      if (!produtoResponse.data || !produtoResponse.data.data) {
        return res.status(200).json({
          sucesso: false,
          erro: `Produto com ID "${produtoId}" não encontrado na API Bling`,
        });
      }

      const produto = produtoResponse.data.data;

      // Extract estoque ID from produto response
      // Assuming estoque ID is in produto.estoque.id or similar structure
      if (!produto.estoque || !produto.estoque.id) {
        return res.status(200).json({
          sucesso: false,
          erro: `Produto com ID "${produtoId}" não possui estoque associado`,
        });
      }

      estoqueId = produto.estoque.id;
    } catch (blingError) {
      logger.error(`Erro ao consultar Bling API (GET /produtos): ${blingError.message}`);
      return res.status(200).json({
        sucesso: false,
        erro: `Erro ao consultar produto na API Bling: ${blingError.response?.data?.message || blingError.message}`,
      });
    }

    // Step 3: Call Bling API PATCH /estoques/{id} to update stock
    try {
      const patchResponse = await axios.patch(
        `https://bling.com.br/api/v3/estoques/${estoqueId}`,
        { saldo: quantidade_atual },
        {
          headers: {
            'Authorization': `Bearer ${blingApiToken}`,
            'Content-Type': 'application/json',
            'Accept': 'application/json',
          },
        }
      );

      logger.info(`Estoque sincronizado com sucesso: SKU=${sku}, estoqueId=${estoqueId}, quantidade=${quantidade_atual}`);

      return res.status(200).json({
        sucesso: true,
        erro: null,
      });
    } catch (blingError) {
      logger.error(`Erro ao atualizar estoque na Bling API: ${blingError.message}`);
      return res.status(200).json({
        sucesso: false,
        erro: `Erro ao atualizar estoque na API Bling: ${blingError.response?.data?.message || blingError.message}`,
      });
    }
  } catch (error) {
    logger.error(`Erro inesperado em sincronizarEstoque: ${error.message}`);
    return res.status(200).json({
      sucesso: false,
      erro: `Erro inesperado: ${error.message}`,
    });
  }
};

router.get('/auth', handleBlingAuth);
router.post('/auth', handleBlingAuth);
router.post('/sincronizar-estoque', sincronizarEstoque);

export default router;