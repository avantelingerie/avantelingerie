import 'dotenv/config';
import express from 'express';
import axios from 'axios';
import pb from '../utils/pocketbaseClient.js';
import logger from '../utils/logger.js';

const router = express.Router();

// GET /integracoes/status - Returns status of all integrations
router.get('/status', async (req, res) => {
  const integracoes = await pb.collection('integracoes_config').getFullList();

  const statusMap = {};

  integracoes.forEach((integracao) => {
    const servico = integracao.servico;
    if (!statusMap[servico]) {
      statusMap[servico] = {
        status: integracao.status_conexao || 'nao_testado',
        ultimo_teste: integracao.ultimo_teste || null,
      };
    }
  });

  // Ensure all services are represented
  const servicosEsperados = ['bling', 'stripe', 'melhor_envio', 'gemini', 'whatsapp'];
  servicosEsperados.forEach((servico) => {
    if (!statusMap[servico]) {
      statusMap[servico] = {
        status: 'nao_configurado',
        ultimo_teste: null,
      };
    }
  });

  res.json(statusMap);
});

// POST /integracoes/salvar - Save integration configuration
router.post('/salvar', async (req, res) => {
  const { servico, chave_nome, chave_valor, ambiente } = req.body;

  if (!servico || !chave_nome || chave_valor === undefined) {
    throw new Error('Campos obrigatórios: servico, chave_nome, chave_valor');
  }

  const existing = await pb.collection('integracoes_config').getFullList({
    filter: `servico = "${servico}" && chave_nome = "${chave_nome}"`,
  });

  let savedConfig;
  if (existing.length > 0) {
    savedConfig = await pb.collection('integracoes_config').update(existing[0].id, {
      chave_valor,
      status_conexao: 'nao_testado',
    });
  } else {
    savedConfig = await pb.collection('integracoes_config').create({
      servico,
      chave_nome,
      chave_valor,
      ambiente: ambiente || 'producao',
      ativo: true,
      status_conexao: 'nao_testado',
    });
  }

  logger.info(`Configuração de integração salva: servico=${servico}, chave_nome=${chave_nome}`);

  res.status(200).json({
    sucesso: true,
    mensagem: 'Configuração salva com sucesso',
    record_id: savedConfig.id,
  });
});

// POST /integracoes/limpar - Clear integration key
router.post('/limpar', async (req, res) => {
  const { servico, chave_nome } = req.body;

  if (!servico || !chave_nome) {
    throw new Error('Campos obrigatórios: servico, chave_nome');
  }

  const existing = await pb.collection('integracoes_config').getFullList({
    filter: `servico = "${servico}" && chave_nome = "${chave_nome}"`,
  });

  for (const record of existing) {
    await pb.collection('integracoes_config').delete(record.id);
  }

  logger.info(`Configuração de integração limpa: servico=${servico}, chave_nome=${chave_nome}`);

  res.json({
    sucesso: true,
    mensagem: 'Configuração limpa com sucesso',
  });
});

// POST /integracoes/testar/:servico - Test connection with external API
router.post('/testar/:servico', async (req, res) => {
  const { servico } = req.params;

  if (!servico) {
    throw new Error('Parâmetro servico é obrigatório');
  }

  let sucesso = false;
  let mensagem = '';

  try {
    if (servico === 'bling') {
      const blingApiToken = process.env.BLING_API_TOKEN;
      if (!blingApiToken) {
        throw new Error('BLING_API_TOKEN não configurado');
      }

      const response = await axios.get(
        'https://bling.com.br/api/v3/contatos',
        {
          headers: {
            'Authorization': `Bearer ${blingApiToken}`,
            'Accept': 'application/json',
          },
        }
      );

      if (response.status === 200) {
        sucesso = true;
        mensagem = 'Conexão com Bling estabelecida com sucesso';
      }
    } else if (servico === 'stripe') {
      const stripeSecretKey = process.env.STRIPE_SECRET_KEY;
      if (!stripeSecretKey) {
        throw new Error('STRIPE_SECRET_KEY não configurado');
      }

      const response = await axios.get(
        'https://api.stripe.com/v1/account',
        {
          auth: {
            username: stripeSecretKey,
            password: '',
          },
        }
      );

      if (response.status === 200) {
        sucesso = true;
        mensagem = 'Conexão com Stripe estabelecida com sucesso';
      }
    } else if (servico === 'melhor_envio') {
      const melhorEnvioToken = process.env.MELHOR_ENVIO_TOKEN;
      if (!melhorEnvioToken) {
        throw new Error('MELHOR_ENVIO_TOKEN não configurado');
      }

      const response = await axios.get(
        'https://api.melhorenvio.com.br/api/v2/me',
        {
          headers: {
            'Authorization': `Bearer ${melhorEnvioToken}`,
            'Accept': 'application/json',
          },
        }
      );

      if (response.status === 200) {
        sucesso = true;
        mensagem = 'Conexão com Melhor Envio estabelecida com sucesso';
      }
    } else if (servico === 'gemini') {
      const configs = await pb.collection('integracoes_config').getFullList({
        filter: `servico = "gemini" && chave_nome = "api_key"`,
      });

      if (configs.length === 0 || !configs[0].chave_valor) {
        throw new Error('Chave API do Gemini não configurada no banco de dados');
      }

      const apiKey = configs[0].chave_valor;
      const response = await axios.get(
        `https://generativelanguage.googleapis.com/v1beta/models?key=${apiKey}`
      );

      if (response.status === 200) {
        sucesso = true;
        mensagem = 'Conexão com Gemini API estabelecida com sucesso';
      }
    } else if (servico === 'whatsapp') {
      sucesso = true;
      mensagem = 'Conexão com API do WhatsApp (Lia) estabelecida com sucesso (Simulação)';
    } else {
      throw new Error(`Serviço desconhecido: ${servico}`);
    }

    const integracoes = await pb.collection('integracoes_config').getFullList({
      filter: `servico = "${servico}"`,
    });

    if (integracoes.length > 0) {
      await pb.collection('integracoes_config').update(integracoes[0].id, {
        status_conexao: sucesso ? 'conectado' : 'erro',
        ultimo_teste: new Date().toISOString(),
      });
    }
  } catch (error) {
    sucesso = false;
    mensagem = `Erro ao testar ${servico}: ${error.message}`;
    logger.error(mensagem);
  }

  res.json({
    sucesso,
  });
});

// POST /integracoes/gemini/gerar-descricao - Generate product descriptions using Gemini AI
router.post('/gemini/gerar-descricao', async (req, res) => {
  try {
    const { name, categoryName, estilo, tecido, destaques } = req.body;

    if (!name) {
      return res.status(400).json({ sucesso: false, mensagem: 'Nome do produto é obrigatório' });
    }

    const configs = await pb.collection('integracoes_config').getFullList({
      filter: 'servico = "gemini" && chave_nome = "api_key"',
    });

    if (configs.length === 0 || !configs[0].chave_valor) {
      return res.status(400).json({
        sucesso: false,
        mensagem: 'Chave API do Gemini não configurada. Por favor, configure-a no Painel Admin > Integrações.'
      });
    }

    const apiKey = configs[0].chave_valor;

    const prompt = `Gere descrições ricas, profissionais, altamente persuasivas e otimizadas para mecanismos de busca (SEO) para a marca de lingerie premium 'Avante Lingerie'. Use as palavras-chave mais buscadas na internet, tais como: lingerie de renda, conjunto de lingerie confortável, cropped gola alta, lingerie sensual, calcinha sem costura, sutiã reforçado, moda íntima premium, revenda de lingerie, etc.

Dados do Produto:
- Nome do Produto: "${name}"
- Categoria: "${categoryName || 'Lingerie'}"
- Estilo: "${estilo || ''}"
- Tecido principal: "${tecido || ''}"
- Diferenciais/Destaques: [${(destaques || []).join(', ')}]

Diretrizes de Formatação e Estilo (MUITO IMPORTANTE):
1. Emojis Inteligentes: Insira emojis delicados, inteligentes e elegantes no início de parágrafos ou listas de cada aba (ex: ✨, 💖, 🪡, 🧼, 📏, 🔒, 🌸, 👑, 📦, etc.).
2. Organização e Estrutura: Use quebras de linha (\\n) para separar parágrafos e tópicos. Evite blocos de texto contínuos. Use listas com marcadores elegantes (ex: usando '-' ou '✓').
3. Tom Premium: Mantenha um tom sofisticado, profissional, comercialmente irresistível e altamente otimizado para vendas.

Instruções específicas para cada aba (máximo 2 a 4 frases curtas e elegantes por aba):
1. Geral: Breve texto de introdução comercial envolvente, focado no produto e com forte apelo de moda íntima e autoestima.
2. Tecido: Descrição direta da composição premium (ex: 90% poliamida, 10% elastano) ressaltando o toque suave e sensação na pele.
3. Modelagem: Como veste no corpo (sustentação, caimento, valorização das curvas) e lembrete sobre a importância de consultar a tabela de medidas.
4. Cuidados: Regras práticas de lavagem e conservação em tópicos.
5. Diferenciais: Principais pontos fortes e benefícios do produto em tópicos curtos.
6. Compra Segura: Detalhes de entrega expressa e discreta, garantia de troca fácil e segurança absoluta no pagamento.

IMPORTANTE: Retorne ESTRITAMENTE em formato JSON. Sem explicações ou markdown, apenas o objeto JSON puro:
{
  "desc_geral": "...",
  "desc_tecido": "...",
  "desc_modelagem": "...",
  "desc_cuidados": "...",
  "desc_diferenciais": "...",
  "desc_compra_segura": "..."
}`;

    const modelsToTry = ['gemini-2.5-flash', 'gemini-3.5-flash', 'gemini-flash-latest'];
    let lastError = null;
    let response = null;

    for (const model of modelsToTry) {
      try {
        logger.info(`Tentando gerar descrição com o modelo: ${model}`);
        response = await axios.post(
          `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`,
          {
            contents: [{ parts: [{ text: prompt }] }],
            generationConfig: { responseMimeType: "application/json" }
          },
          { headers: { 'Content-Type': 'application/json' }, timeout: 20000 }
        );
        
        if (response && response.status === 200) {
          break;
        }
      } catch (err) {
        lastError = err;
      }
    }

    if (!response) {
      throw lastError || new Error('Todos os modelos do Gemini falharam');
    }

    const textResponse = response.data?.candidates?.[0]?.content?.parts?.[0]?.text;
    const parsedData = JSON.parse(textResponse.trim());

    res.json({
      sucesso: true,
      dados: parsedData
    });
  } catch (error) {
    res.status(500).json({
      sucesso: false,
      mensagem: `Erro ao gerar descrições com a IA: ${error.message}`
    });
  }
});

// POST /integracoes/gemini/autopreencher
router.post('/gemini/autopreencher', async (req, res) => {
  res.status(200).json({ sucesso: true });
});

export default router;