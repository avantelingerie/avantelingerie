import React, { useState } from 'react';
import { Truck, MapPin } from 'lucide-react';
import { Input } from '@/components/ui/input.jsx';
import { Button } from '@/components/ui/button.jsx';
import { motion } from 'framer-motion';

export default function SmartShipping({ currentTotal, onSelectShipping }) {
  const [cep, setCep] = useState('');
  const [calculated, setCalculated] = useState(false);
  const [selectedOption, setSelectedOption] = useState(null);

  // Requirement: Faltam R$X para frete grátis com threshold em R$100
  const freeShippingThreshold = 100;
  const diff = freeShippingThreshold - currentTotal;
  const progressPercent = Math.min(100, (currentTotal / freeShippingThreshold) * 100);

  const formatPrice = (val) => new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(val);

  const handleCalculate = () => {
    if (cep.length >= 8) {
      setCalculated(true);
      // Simulate API result
      const cost = diff > 0 ? 15.90 : 0;
      setSelectedOption('pac');
      onSelectShipping({ cost, method: 'PAC' });
    }
  };

  const handleOptionChange = (method, cost) => {
    setSelectedOption(method);
    onSelectShipping({ cost, method });
  };

  return (
    <div className="bg-card border border-primary/10 rounded-2xl p-6 shadow-sm">
      <div className="flex items-center gap-2 mb-4">
        <Truck className="w-5 h-5 text-primary" />
        <h3 className="font-bold text-foreground">Calcular Frete e Prazo</h3>
      </div>

      <div className="flex gap-2 mb-5">
        <div className="relative flex-grow">
          <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input 
            placeholder="00000-000" 
            className="pl-9 bg-background border-primary/20 focus-visible:ring-primary h-11"
            value={cep}
            maxLength={9}
            onChange={(e) => {
              const val = e.target.value.replace(/\D/g, '');
              const formatted = val.length > 5 ? val.replace(/^(\d{5})(\d)/, '$1-$2') : val;
              setCep(formatted);
            }}
          />
        </div>
        <Button 
          onClick={handleCalculate} 
          variant="outline" 
          className="border-primary/20 hover:bg-primary/5 h-11 px-6 font-medium text-foreground"
          disabled={cep.replace(/\D/g, '').length < 8}
        >
          OK
        </Button>
      </div>

      {/* Free Shipping Progress */}
      <div className="mb-4">
        <div className="flex justify-between text-xs font-medium mb-1.5">
          <span className="text-muted-foreground">Frete Grátis</span>
          <span className={diff > 0 ? "text-primary" : "text-green-600 font-bold"}>
            {diff > 0 ? `Falta ${formatPrice(diff)}` : 'Desbloqueado!'}
          </span>
        </div>
        <div className="h-2 w-full bg-muted rounded-full overflow-hidden">
          <motion.div 
            className={`h-full ${diff > 0 ? 'bg-primary' : 'bg-green-500'}`}
            initial={{ width: 0 }}
            animate={{ width: `${progressPercent}%` }}
            transition={{ duration: 0.5 }}
          />
        </div>
      </div>

      {calculated && (
        <div className="mt-4 space-y-3 border-t border-primary/10 pt-4">
          <label className={`flex items-center justify-between p-3 border rounded-xl cursor-pointer transition-colors ${selectedOption === 'pac' ? 'border-primary bg-primary/5' : 'border-primary/20 hover:bg-muted/50'}`}>
            <div className="flex items-center gap-3">
              <input 
                type="radio" 
                name="shipping" 
                checked={selectedOption === 'pac'}
                onChange={() => handleOptionChange('pac', diff > 0 ? 15.90 : 0)}
                className="text-primary focus:ring-primary" 
              />
              <div>
                <div className="font-bold text-sm text-foreground">Correios PAC</div>
                <div className="text-xs text-muted-foreground">Até 7 dias úteis</div>
              </div>
            </div>
            <div className="font-bold text-sm text-foreground">
              {diff > 0 ? formatPrice(15.90) : <span className="text-green-600">Grátis</span>}
            </div>
          </label>
          <label className={`flex items-center justify-between p-3 border rounded-xl cursor-pointer transition-colors ${selectedOption === 'sedex' ? 'border-primary bg-primary/5' : 'border-primary/20 hover:bg-muted/50'}`}>
            <div className="flex items-center gap-3">
              <input 
                type="radio" 
                name="shipping" 
                checked={selectedOption === 'sedex'}
                onChange={() => handleOptionChange('sedex', 32.50)}
                className="text-primary focus:ring-primary" 
              />
              <div>
                <div className="font-bold text-sm text-foreground">Correios Sedex</div>
                <div className="text-xs text-muted-foreground">Até 3 dias úteis</div>
              </div>
            </div>
            <div className="font-bold text-sm text-foreground">{formatPrice(32.50)}</div>
          </label>
        </div>
      )}
    </div>
  );
}