import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { 
  ShieldCheck, 
  RefreshCw, 
  Truck, 
  HeartHandshake, 
  Instagram, 
  Facebook, 
  Phone, 
  Mail, 
  Lock, 
  CreditCard,
  Shield,
  CheckCircle,
  Award
} from 'lucide-react';
import { toast } from 'sonner';
import pb from '@/lib/pocketbaseClient';

export default function Footer() {
  const [email, setEmail] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubscribe = async (e) => {
    e.preventDefault();
    if (!email || !email.includes('@')) {
      toast.error('Por favor, insira um e-mail válido.');
      return;
    }
    
    setIsLoading(true);
    try {
      await pb.collection('newsletter_signups').create({ email }, { $autoCancel: false });
      toast.success('Inscrição realizada com sucesso! Bem-vinda à nossa lista VIP.');
      setEmail('');
    } catch (error) {
      console.error('Erro ao assinar newsletter:', error);
      toast.error('Não foi possível realizar a inscrição. Tente novamente mais tarde.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      {/* ==========================================
          TRUST BAR (POR QUE ESCOLHER A AVANTE)
          ========================================== */}
      <div className="bg-[#FFF8F5] border-t border-[#c59b5f]/20 py-16 px-4">
        <div className="max-w-7xl mx-auto text-center">
          <span className="text-[10px] md:text-xs font-bold uppercase tracking-[3px] text-[#c59b5f]">
            Compromisso e Elegância
          </span>
          <h3 className="text-2xl md:text-3.5xl font-serif font-bold text-gray-900 mt-2 mb-12">
            Por que escolher a Avante?
          </h3>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-10 md:gap-8 max-w-6xl mx-auto">
            <div className="flex flex-col items-center text-center group">
              <div className="w-16 h-16 rounded-full bg-white border border-[#c59b5f]/30 flex items-center justify-center mb-4 transition-all duration-300 group-hover:bg-[#c59b5f] group-hover:scale-105 shadow-sm">
                <ShieldCheck className="w-7 h-7 text-[#c59b5f] group-hover:text-black transition-colors" />
              </div>
              <span className="text-base font-bold font-serif text-gray-900 mb-2">Compra 100% Segura</span>
              <p className="text-gray-500 text-sm leading-relaxed max-w-[240px]">
                Seus dados pessoais e de pagamento estão totalmente criptografados e protegidos.
              </p>
            </div>

            <div className="flex flex-col items-center text-center group">
              <div className="w-16 h-16 rounded-full bg-white border border-[#c59b5f]/30 flex items-center justify-center mb-4 transition-all duration-300 group-hover:bg-[#c59b5f] group-hover:scale-105 shadow-sm">
                <RefreshCw className="w-7 h-7 text-[#c59b5f] group-hover:text-black transition-colors" />
              </div>
              <span className="text-base font-bold font-serif text-gray-900 mb-2">Troca Facilitada</span>
              <p className="text-gray-500 text-sm leading-relaxed max-w-[240px]">
                A primeira troca de suas lingeries é grátis em até 7 dias após o recebimento.
              </p>
            </div>

            <div className="flex flex-col items-center text-center group">
              <div className="w-16 h-16 rounded-full bg-white border border-[#c59b5f]/30 flex items-center justify-center mb-4 transition-all duration-300 group-hover:bg-[#c59b5f] group-hover:scale-105 shadow-sm">
                <Truck className="w-7 h-7 text-[#c59b5f] group-hover:text-black transition-colors" />
              </div>
              <span className="text-base font-bold font-serif text-gray-900 mb-2">Entrega Rápida</span>
              <p className="text-gray-500 text-sm leading-relaxed max-w-[240px]">
                Parceria com as melhores transportadoras do país para entrega ágil e rastreada.
              </p>
            </div>

            <div className="flex flex-col items-center text-center group">
              <div className="w-16 h-16 rounded-full bg-white border border-[#c59b5f]/30 flex items-center justify-center mb-4 transition-all duration-300 group-hover:bg-[#c59b5f] group-hover:scale-105 shadow-sm">
                <HeartHandshake className="w-7 h-7 text-[#c59b5f] group-hover:text-black transition-colors" />
              </div>
              <span className="text-base font-bold font-serif text-gray-900 mb-2">Atendimento Humanizado</span>
              <p className="text-gray-500 text-sm leading-relaxed max-w-[240px]">
                Nossa equipe premium de consultoras de estilo pronta para tirar dúvidas via WhatsApp.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* ==========================================
          MAIN LUXURY FOOTER
          ========================================== */}
      <footer className="bg-[#121212] text-gray-300 pt-16 pb-8 px-4 sm:px-6 lg:px-8 border-t-2 border-[#c59b5f]">
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-12 lg:gap-8 pb-12 border-b border-[#c59b5f]/20">
          
          {/* Coluna 1: Marca & Redes */}
          <div className="lg:col-span-1 space-y-6">
            <Link to="/" className="inline-block">
              <img 
                src="https://horizons-cdn.hostinger.com/2863a2ab-708d-40c9-b019-44d46f1b8bc1/2cc53c4f87239617896d951f98b0a124.png"
                alt="Avante Lingerie"
                className="h-14 w-auto object-contain brightness-100"
              />
            </Link>
            <p className="text-sm text-gray-400 leading-relaxed font-light">
              Delicadeza, conforto e sensualidade em cada detalhe. Peças exclusivas e atemporais desenvolvidas com o mais alto padrão de qualidade para valorizar a beleza feminina.
            </p>
            <div className="flex items-center gap-3">
              <a 
                href="https://www.instagram.com/avante.lingerie/" 
                target="_blank" 
                rel="noopener noreferrer" 
                className="w-10 h-10 rounded-full bg-white/5 border border-[#c59b5f]/30 flex items-center justify-center text-[#c59b5f] hover:bg-[#c59b5f] hover:text-black transition-all shadow-sm"
              >
                <Instagram className="w-5 h-5" />
              </a>
              <a 
                href="https://www.facebook.com/profile.php?id=61589229361324&locale=pt_BR" 
                target="_blank" 
                rel="noopener noreferrer" 
                className="w-10 h-10 rounded-full bg-white/5 border border-[#c59b5f]/30 flex items-center justify-center text-[#c59b5f] hover:bg-[#c59b5f] hover:text-black transition-all shadow-sm"
              >
                <Facebook className="w-5 h-5" />
              </a>
              <a 
                href="https://wa.me/5522997618591" 
                target="_blank" 
                rel="noopener noreferrer" 
                className="w-10 h-10 rounded-full bg-white/5 border border-[#c59b5f]/30 flex items-center justify-center text-[#c59b5f] hover:bg-[#c59b5f] hover:text-black transition-all shadow-sm"
              >
                <Phone className="w-5 h-5" />
              </a>
            </div>
          </div>

          {/* Coluna 2: Central da Cliente */}
          <div className="space-y-4">
            <h4 className="text-[#c59b5f] font-serif font-bold text-lg tracking-wider">Central da Cliente</h4>
            <ul className="space-y-2.5 text-sm font-medium">
              {/* Correct Fix: Point Minha Conta link to /account to avoid guest lockouts */}
              <li><Link to="/account" className="hover:text-[#c59b5f] transition-colors">Minha Conta</Link></li>
              <li><Link to="/pedidos" className="hover:text-[#c59b5f] transition-colors">Meus Pedidos</Link></li>
              <li><Link to="/rastreio" className="hover:text-[#c59b5f] transition-colors">Rastrear Pedido</Link></li>
              <li><Link to="/central-da-cliente#trocas-e-devolucoes" className="hover:text-[#c59b5f] transition-colors">Trocas e Devoluções</Link></li>
              <li><Link to="/faq" className="hover:text-[#c59b5f] transition-colors">Dúvidas Frequentes</Link></li>
            </ul>
          </div>

          {/* Coluna 3: Institucional */}
          <div className="space-y-4">
            <h4 className="text-[#c59b5f] font-serif font-bold text-lg tracking-wider">Institucional</h4>
            <ul className="space-y-2.5 text-sm font-medium">
              <li><Link to="/sobre" className="hover:text-[#c59b5f] transition-colors">Sobre a Avante</Link></li>
              <li><Link to="/lojas" className="hover:text-[#c59b5f] transition-colors">Nossas Lojas</Link></li>
              <li><Link to="/quero-revender" className="hover:text-[#c59b5f] transition-colors">Quero ser Revendedora</Link></li>
              <li><Link to="/central-da-cliente#politica-de-privacidade" className="hover:text-[#c59b5f] transition-colors">Política de Privacidade</Link></li>
              <li><Link to="/central-da-cliente#termos-de-uso" className="hover:text-[#c59b5f] transition-colors">Termos de Serviço</Link></li>
              <li><Link to="/central-da-cliente#fale-conosco" className="hover:text-[#c59b5f] transition-colors">Fale Conosco</Link></li>
            </ul>
          </div>

          {/* Coluna 4: Confiança e Segurança Premium */}
          <div className="space-y-4">
            <h4 className="text-[#c59b5f] font-serif font-bold text-lg tracking-wider">Segurança & Selos</h4>
            <div className="space-y-3">
              {/* SSL Let's Encrypt */}
              <div className="flex items-center gap-3 bg-white/5 border border-white/10 rounded-xl p-3 shadow-inner hover:border-sky-500/30 transition-all duration-300 group/selo">
                <div className="w-9 h-9 rounded-lg bg-sky-500/10 border border-sky-500/20 flex items-center justify-center text-sky-400 shadow-sm shrink-0 group-hover/selo:scale-105 transition-transform duration-300">
                  <Lock className="w-5 h-5" />
                </div>
                <div className="text-xs">
                  <p className="font-bold text-white">Ambiente Seguro SSL</p>
                  <p className="text-gray-400 font-light text-[10px]">Criptografia Let's Encrypt</p>
                </div>
              </div>
              
              {/* Google Safe Browsing */}
              <div className="flex items-center gap-3 bg-white/5 border border-white/10 rounded-xl p-3 shadow-inner hover:border-green-500/30 transition-all duration-300 group/selo">
                <div className="w-9 h-9 rounded-lg bg-green-500/10 border border-green-500/20 flex items-center justify-center text-green-400 shadow-sm shrink-0 group-hover/selo:scale-105 transition-transform duration-300">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <div className="text-xs">
                  <p className="font-bold text-white">Google Safe Browsing</p>
                  <p className="text-gray-400 font-light text-[10px]">Site Seguro & Verificado</p>
                </div>
              </div>

              {/* Ebit Diamante */}
              <div className="flex items-center gap-3 bg-white/5 border border-white/10 rounded-xl p-3 shadow-inner hover:border-amber-500/30 transition-all duration-300 group/selo">
                <div className="w-9 h-9 rounded-lg bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400 shadow-sm shrink-0 group-hover/selo:scale-105 transition-transform duration-300">
                  <Award className="w-5 h-5" />
                </div>
                <div className="text-xs">
                  <p className="font-bold text-white">Ebit Diamante Excelente</p>
                  <p className="text-gray-400 font-light text-[10px]">Qualidade & Entrega Garantida</p>
                </div>
              </div>
            </div>
          </div>

          {/* Coluna 5: Newsletter */}
          <div className="space-y-4">
            <h4 className="text-[#c59b5f] font-serif font-bold text-lg tracking-wider">Lista VIP Avante</h4>
            <p className="text-sm text-gray-400 leading-relaxed font-light">
              Receba novidades exclusivas e 10% de desconto na sua primeira compra de luxo.
            </p>
            <form className="space-y-2" onSubmit={handleSubscribe}>
              <input 
                type="email" 
                placeholder="Seu melhor e-mail" 
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                disabled={isLoading}
                className="w-full bg-white/5 border border-[#c59b5f]/30 focus:border-[#c59b5f] outline-none text-white text-sm py-2.5 px-4 rounded-xl placeholder-gray-500 transition-colors"
                required
              />
              <button 
                type="submit" 
                disabled={isLoading}
                className="w-full bg-[#c59b5f] hover:bg-white text-black font-bold text-xs uppercase tracking-wider py-3 rounded-xl transition-all cursor-pointer shadow-md disabled:opacity-50 shrink-0 flex items-center justify-center gap-2"
              >
                {isLoading ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" /> Enviando...
                  </>
                ) : (
                  <>
                    <Mail className="w-4 h-4" /> Entrar na Lista VIP
                  </>
                )}
              </button>
            </form>
          </div>

        </div>

        {/* Footer Bottom (Copyright + Cartões + Selos de Confiança) */}
        <div className="max-w-7xl mx-auto pt-8 flex flex-col md:flex-row justify-between items-center gap-6">
          <div className="text-center md:text-left space-y-1">
            <p className="text-xs text-gray-500 font-light">
              &copy; {new Date().getFullYear()} Avante Lingerie. Todos os direitos reservados.
            </p>
            <p className="text-[10px] text-gray-600 font-light leading-relaxed max-w-2xl">
              AVANTE INDUSTRIA E COMERCIO DE VESTUARIO LTDA | CNPJ: 12.345.678/0001-90<br />
              Rua Folly, 69, Olaria, Nova Friburgo — RJ | CEP: 28620-190
            </p>
          </div>

          <div className="flex items-center gap-3 flex-wrap justify-center shrink-0 opacity-75">
            <div className="bg-white/5 border border-white/10 rounded-lg p-2.5 flex items-center justify-center" title="Boleto Bancário">
              <span className="text-[9px] font-extrabold tracking-widest text-[#c59b5f] uppercase leading-none">Boleto</span>
            </div>
            <div className="bg-white/5 border border-white/10 rounded-lg p-2.5 flex items-center justify-center" title="PIX">
              <span className="text-[9px] font-extrabold tracking-widest text-[#c59b5f] uppercase leading-none">PIX</span>
            </div>
            <div className="bg-white/5 border border-white/10 rounded-lg p-2.5 flex items-center justify-center" title="Cartões de Crédito">
              <CreditCard className="w-5 h-5 text-[#c59b5f]" />
            </div>
            <div className="bg-white/5 border border-white/10 rounded-lg p-2.5 flex items-center justify-center" title="Pagamento Criptografado SSL">
              <Shield className="w-5 h-5 text-[#c59b5f]" />
            </div>
          </div>
        </div>
      </footer>
    </>
  );
}