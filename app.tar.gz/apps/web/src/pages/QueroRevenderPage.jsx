// Caminho do arquivo: apps/web/src/pages/QueroRevenderPage.jsx
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  DollarSign, Award, ShieldCheck, Crown, ShoppingBag,
  ArrowRight, Check, HelpCircle, Users, Download,
  Percent, Smartphone, Copy, CheckCircle2, AlertCircle
} from 'lucide-react';
import pb from '@/lib/pocketbaseClient.js';
import { toast } from 'sonner';

export default function QueroRevenderPage() {
  // Simulator State
  const [investimento, setInvestimento] = useState(1000);

  // Form State
  const [formData, setFormData] = useState({
    nome: '',
    whatsapp: '',
    email: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState(false);

  // FAQ Accordion State
  const [openFaqIndex, setOpenFaqIndex] = useState(null);

  // Profit calculations based on wholesale logic
  const ticketMedioPeca = 25; // Custo médio de atacado por peça
  const pecasEstimadas = Math.round(investimento / ticketMedioPeca);
  const retornoEstimado = Math.round(investimento * 2.5); // Vende por 2.5x o valor pago (150% de lucro)
  const lucroLiquido = retornoEstimado - investimento;

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.nome || !formData.whatsapp || !formData.email) {
      toast.error('Por favor, preencha todos os campos.');
      return;
    }

    setIsSubmitting(true);
    try {
      // Capture UTMs from localStorage if they exist (Marketing tracking logic)
      const utm_source = localStorage.getItem('utm_source') || 'organico';
      const utm_campaign = localStorage.getItem('utm_campaign') || 'direto';

      // Save lead to PocketBase
      try {
        await pb.collection('leads_revenda').create({
          nome: formData.nome,
          email: formData.email,
          whatsapp: formData.whatsapp,
          utm_source: utm_source,
          utm_campaign: utm_campaign,
          status: 'pendente'
        });
      } catch (pbError) {
        console.warn('Coleção leads_revenda pode não estar criada no PocketBase. Continuando fluxo...', pbError);
      }

      // Success Feedback
      toast.success('Pré-cadastro realizado com sucesso! Seja bem-vinda à Avante Lingerie!');
      setSubmitSuccess(true);

      // Clear form
      setFormData({ nome: '', whatsapp: '', email: '' });

      // Trigger standard pixel lead event if pixel is loaded
      if (window.fbq) {
        window.fbq('track', 'Lead', {
          content_category: 'Reseller Lead',
          value: investimento,
          currency: 'BRL'
        });
      }
    } catch (error) {
      console.error('Erro no pré-cadastro:', error);
      toast.error('Erro ao realizar cadastro. Por favor, tente novamente.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const faqData = [
    {
      q: "Qual é o valor mínimo para a primeira compra de revendedora?",
      a: "Para liberar o seu acesso à nossa tabela exclusiva de preços de custo (atacado) e garantir a exclusividade, o pedido mínimo inicial é de apenas R$ 400,00 no carrinho (já calculados com o desconto de atacado aplicado)."
    },
    {
      q: "Preciso ter CNPJ para começar a revender?",
      a: "Não! Você pode iniciar o seu negócio imediatamente utilizando o seu CPF. Se futuramente você formalizar sua empresa e desejar migrar para os níveis Verified ou Gold para receber mais benefícios tributários e kits exclusivos, nosso time de suporte fará a alteração em segundos."
    },
    {
      q: "Como funciona a liberação de fotos e vídeos promocionais?",
      a: "Todas as nossas parceiras têm acesso ao Portal Restrito. As parceiras do nível Gold possuem liberação direta de download de lotes completos de fotos de estúdio profissionais e vídeos reels de alta qualidade das modelos para postarem em suas redes sociais e venderem antes mesmo da peça física chegar!"
    },
    {
      q: "Quais são as formas de pagamento aceitas?",
      a: "Oferecemos 10% de desconto adicional para pagamentos à vista via Pix, ou parcelamento em até 3x sem juros em todos os cartões de crédito para facilitar o fluxo de caixa do seu negócio de revenda."
    },
    {
      q: "Como é calculado o frete para a minha região?",
      a: "Trabalhamos com integração direta ao Melhor Envio, garantindo as tarifas de frete mais baratas do mercado (Correios, Jadlog, Latam Cargo). A partir de determinados volumes de compras de nível Gold, liberamos campanhas de frete grátis ou com subsídio."
    }
  ];

  return (
    <div className="min-h-screen bg-[#121212] text-white overflow-x-hidden pt-24 md:pt-28 pb-16 font-sans">

      {/* SECTION 1: HERO SECTION */}
      <section className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-20">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">

          {/* Hero Content */}
          <div className="lg:col-span-7 space-y-6 text-left">
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-[#C59B5F]/15 border border-[#C59B5F]/30 text-[#C59B5F] font-bold text-xs tracking-wider uppercase">
              <Crown className="w-3.5 h-3.5 animate-pulse" /> Clube de Parceiras Avante
            </div>

            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-serif font-bold text-white leading-tight drop-shadow-sm">
              Transforme sua paixão por moda em <span className="text-[#C59B5F]">independência financeira</span>.
            </h1>

            <p className="text-white/70 text-lg font-light leading-relaxed max-w-2xl">
              Revenda lingeries premium de Nova Friburgo com lucros reais de até 150%.
              Ganhe acesso imediato a preços de atacado direto de fábrica, kits prontos e material profissional de marketing para explodir suas vendas nas redes sociais.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 pt-4">
              <a
                href="/portal-revenda"
                className="px-8 py-4 bg-[#C59B5F] hover:bg-[#b0874e] text-black font-bold text-sm uppercase tracking-wider rounded-full shadow-lg transition-all duration-300 flex items-center justify-center gap-3 group"
              >
                Acessar Portal de Revenda <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </a>
              <a
                href="#cadastro"
                className="px-8 py-4 bg-[#1a1a1a] border border-[#C59B5F]/30 hover:border-[#C59B5F] text-white font-bold text-sm uppercase tracking-wider rounded-full shadow-sm transition-all duration-300 flex items-center justify-center gap-2"
              >
                Fazer Pré-Cadastro
              </a>
            </div>

            {/* Quick Proof Trust Bars */}
            <div className="grid grid-cols-3 gap-4 border-t border-white/10 pt-8 mt-4 text-left">
              <div>
                <p className="text-2xl font-bold text-[#C59B5F] font-serif">+1.200</p>
                <p className="text-xs text-white/50 uppercase tracking-wider">Peças enviadas/semana</p>
              </div>
              <div>
                <p className="text-2xl font-bold text-[#C59B5F] font-serif">150%</p>
                <p className="text-xs text-white/50 uppercase tracking-wider">De retorno estimado</p>
              </div>
              <div>
                <p className="text-2xl font-bold text-[#C59B5F] font-serif">100%</p>
                <p className="text-xs text-white/50 uppercase tracking-wider">Fotos/Vídeos inclusos</p>
              </div>
            </div>
          </div>

          {/* Hero Video Mockup (Premium Aesthetic) */}
          <div className="lg:col-span-5 relative flex justify-center">
            <div className="absolute inset-0 bg-[#C59B5F]/10 rounded-3xl filter blur-3xl transform rotate-6 scale-95" />
            <div className="relative border-4 border-[#C59B5F]/30 bg-[#1a1a1a] rounded-[32px] overflow-hidden shadow-2xl w-full max-w-[420px] aspect-[4/5] flex items-center justify-center group transition-transform duration-500 hover:scale-[1.01]">
              <video
                src="https://lmdesignerweb.com/video/video_revenda_avante.mp4"
                autoPlay
                loop
                muted
                playsInline
                controls
                className="absolute inset-0 w-full h-full object-cover brightness-75 group-hover:scale-105 transition-transform duration-700"
              />
              <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-[#121212]/95 via-[#121212]/40 to-transparent p-8 text-left space-y-2 pointer-events-none z-10">
                <div className="flex gap-1 text-[#C59B5F]">
                  <Crown className="w-4 h-4 fill-current" />
                  <Crown className="w-4 h-4 fill-current" />
                  <Crown className="w-4 h-4 fill-current" />
                </div>
                <p className="text-white text-lg font-serif font-bold">Coleção Satin Gold 2026</p>
                <p className="text-white/80 text-xs font-light">Lingeries de alta costura com margem imbatível de revenda.</p>
              </div>
            </div>
          </div>

        </div>
      </section>

      {/* SECTION 2: INTERACTIVE PROFIT SIMULATOR (Background updated to light rose cream #fff8f5 per user request) */}
      <section id="simulador" className="py-16 bg-[#fff8f5] border-y border-[#b0874e]/20 scroll-mt-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-12">

          <div className="max-w-3xl mx-auto space-y-4">
            <span className="text-[#b0874e] text-xs font-bold uppercase tracking-wider">Faça as Contas do Seu Sucesso</span>
            <h2 className="text-3xl sm:text-4xl font-serif font-bold text-[#2C1E1A]">
              Simulador de Lucros Interativo
            </h2>
            <p className="text-[#5C4D4A] font-light">
              Escolha o valor que deseja investir em mercadorias e veja na hora o número estimado de conjuntos premium recebidos, o valor de revenda sugerido e o lucro líquido real no seu bolso.
            </p>
          </div>

          {/* Core tools block wrapper remains beautifully dark as requested */}
          <div className="max-w-4xl mx-auto bg-[#121212] rounded-[24px] border border-[#b0874e]/30 p-8 md:p-12 shadow-2xl grid grid-cols-1 lg:grid-cols-12 gap-8 text-left relative overflow-hidden">
            <div className="absolute top-0 right-0 w-64 h-64 bg-[#C59B5F]/5 rounded-full filter blur-2xl transform translate-x-1/2 -translate-y-1/2" />

            {/* Slider Controls */}
            <div className="lg:col-span-7 space-y-8 z-10">
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <label className="text-sm font-bold uppercase tracking-wider text-white/70">
                    Quanto deseja investir?
                  </label>
                  <span className="text-3xl font-bold font-serif text-[#C59B5F]">
                    R$ {investimento.toLocaleString('pt-BR')}
                  </span>
                </div>

                <input
                  type="range"
                  min="400"
                  max="5000"
                  step="100"
                  value={investimento}
                  onChange={(e) => setInvestimento(Number(e.target.value))}
                  className="w-full h-2.5 bg-[#262626] rounded-lg appearance-none cursor-pointer accent-[#C59B5F] border border-white/10"
                />

                <div className="flex justify-between text-xs text-white/40 font-semibold">
                  <span>Mínimo: R$ 400</span>
                  <span>Médio: R$ 2.500</span>
                  <span>Máximo: R$ 5.000</span>
                </div>
              </div>

              {/* Bullet Details */}
              <div className="grid grid-cols-2 gap-6 bg-[#1a1a1a] p-6 rounded-2xl border border-[#b0874e]/20 shadow-inner">
                <div className="space-y-1">
                  <div className="flex items-center gap-2 text-xs font-semibold text-white/60 uppercase tracking-wider">
                    <ShoppingBag className="w-4 h-4 text-[#C59B5F]" /> Peças sugeridas
                  </div>
                  <p className="text-2xl font-bold text-white font-serif">
                    ~ {pecasEstimadas} conjuntos
                  </p>
                  <p className="text-xxs text-white/40">Variados em modelos e cores</p>
                </div>
                <div className="space-y-1">
                  <div className="flex items-center gap-2 text-xs font-semibold text-white/60 uppercase tracking-wider">
                    <Percent className="w-4 h-4 text-[#C59B5F]" /> Margem aplicada
                  </div>
                  <p className="text-2xl font-bold text-white font-serif">
                    150% de ROI
                  </p>
                  <p className="text-xxs text-white/40">Retorno estimado sob custo</p>
                </div>
              </div>
            </div>

            {/* Results Callout */}
            <div className="lg:col-span-5 bg-[#1a1a1a] border border-[#b0874e]/30 text-white p-8 rounded-2xl flex flex-col justify-between shadow-2xl z-10 relative overflow-hidden">
              <div className="absolute top-0 right-0 w-32 h-32 bg-[#C59B5F]/10 rounded-full filter blur-xl transform translate-x-1/2 -translate-y-1/2" />

              <div className="space-y-2">
                <span className="text-[#C59B5F] text-xs font-bold uppercase tracking-wider">Seu Resultado comercial</span>
                <p className="text-sm text-white/70">Você revende o lote total por:</p>
                <p className="text-3xl font-serif font-bold text-[#C59B5F]">
                  R$ {retornoEstimado.toLocaleString('pt-BR')}
                </p>
              </div>

              <div className="border-t border-white/10 pt-6 mt-6 space-y-1">
                <p className="text-xs text-white/50 uppercase tracking-wider">Seu Lucro Líquido Real:</p>
                <p className="text-4xl font-serif font-bold text-emerald-400 animate-pulse">
                  + R$ {lucroLiquido.toLocaleString('pt-BR')}
                </p>
                <p className="text-xxs text-white/40">Dinheiro direto no seu bolso ao concluir as vendas.</p>
              </div>

              <a
                href="/portal-revenda"
                className="mt-8 px-6 py-3.5 bg-[#C59B5F] hover:bg-[#b0874e] text-black font-extrabold text-xs uppercase tracking-wider rounded-xl text-center shadow-lg transition-colors duration-300"
              >
                Garantir Minha Vaga de Revenda
              </a>
            </div>

          </div>

        </div>
      </section>

      {/* SECTION 3: ESCADA DE PRESTÍGIO (LEVELS OF PARTNERSHIP) */}
      <section className="py-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-12">
        <div className="max-w-3xl mx-auto space-y-4">
          <span className="text-[#C59B5F] text-xs font-bold uppercase tracking-wider">Evolução do Seu Negócio</span>
          <h2 className="text-3xl sm:text-4xl font-serif font-bold text-white">
            A Escada de Prestígio Avante
          </h2>
          <p className="text-white/60 font-light">
            Quanto mais você vende, maior é o seu reconhecimento comercial. Suba na nossa hierarquia e desbloqueie combos premium, frete grátis e assessoria VIP de marca.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">

          {/* Bronze Card */}
          <div className="bg-[#1a1a1a] border border-[#b0874e]/30 rounded-2xl p-8 text-left space-y-6 shadow-2xl hover:border-[#C59B5F] transition-all duration-300 relative flex flex-col justify-between">
            <div className="space-y-4">
              <div className="w-12 h-12 bg-amber-700/10 rounded-full flex items-center justify-center text-amber-500">
                <Award className="w-6 h-6 animate-pulse" />
              </div>
              <h3 className="text-xl font-serif font-bold text-white flex items-center justify-between">
                Bronze Partner <span className="text-xs px-2 py-0.5 rounded bg-amber-950/40 text-amber-500 font-sans font-normal uppercase tracking-wider">Nível 1</span>
              </h3>
              <p className="text-white/60 text-sm font-light leading-relaxed">
                Comece sua jornada de vendas de lingeries de alta costura com investimento mínimo e baixo risco.
              </p>
              <ul className="space-y-2.5 text-xs text-white/70 pt-4 border-t border-white/5">
                <li className="flex items-center gap-2"><Check className="w-4 h-4 text-emerald-400" /> Preços de atacado direto da fábrica</li>
                <li className="flex items-center gap-2"><Check className="w-4 h-4 text-emerald-400" /> Margem de revenda acima de 40%</li>
                <li className="flex items-center gap-2"><Check className="w-4 h-4 text-emerald-400" /> Acesso ao Portal da Revendedora</li>
                <li className="flex items-center gap-2"><Check className="w-4 h-4 text-emerald-400" /> Catálogo digital de lançamentos</li>
                <li className="flex items-center gap-2"><Check className="w-4 h-4 text-emerald-400" /> Grupo de suporte oficial</li>
                <li className="flex items-center gap-2"><Check className="w-4 h-4 text-emerald-400" /> Campanhas promocionais coletivas</li>
              </ul>
            </div>
            <div className="pt-6">
              <span className="text-xxs uppercase tracking-wider text-white/40 font-bold block mb-1">Requisito</span>
              <p className="text-sm font-bold text-[#C59B5F]">Cadastro aprovado como revendedora</p>
            </div>
          </div>

          {/* Silver Card (Verified) */}
          <div className="bg-[#1a1a1a] border border-[#C59B5F] rounded-2xl p-8 text-left space-y-6 shadow-2xl hover:scale-[1.02] transition-all duration-300 relative flex flex-col justify-between">
            <div className="absolute top-0 right-8 -translate-y-1/2 bg-[#C59B5F] text-black font-extrabold text-[9px] uppercase tracking-wider py-1 px-3 rounded-full shadow-md">
              Mais Recomendado
            </div>
            <div className="space-y-4">
              <div className="w-12 h-12 bg-blue-500/10 rounded-full flex items-center justify-center text-blue-400">
                <ShieldCheck className="w-6 h-6 animate-pulse" />
              </div>
              <h3 className="text-xl font-serif font-bold text-white flex items-center justify-between">
                Silver Verified <span className="text-xs px-2 py-0.5 rounded bg-blue-950/40 text-blue-400 font-sans font-normal uppercase tracking-wider">Nível 2</span>
              </h3>
              <p className="text-white/60 text-sm font-light leading-relaxed">
                Revendedoras verificadas e formalizadas com prioridade de atendimento e ferramentas de marketing.
              </p>
              <ul className="space-y-2.5 text-xs text-white/70 pt-4 border-t border-white/5">
                <li className="flex items-center gap-2"><Check className="w-4 h-4 text-emerald-400" /> Todos os benefícios do Bronze</li>
                <li className="flex items-center gap-2"><Check className="w-4 h-4 text-emerald-400" /> Selo "Verified" Prateado no Perfil</li>
                <li className="flex items-center gap-2"><Check className="w-4 h-4 text-emerald-400" /> **+2% de Desconto Extra Fixo** na sacola</li>
                <li className="flex items-center gap-2"><Check className="w-4 h-4 text-emerald-400" /> Prioridade no suporte via WhatsApp</li>
                <li className="flex items-center gap-2"><Check className="w-4 h-4 text-emerald-400" /> Kit de boas-vindas digital da parceira</li>
                <li className="flex items-center gap-2"><Check className="w-4 h-4 text-emerald-400" /> Lançamentos liberados 24h antes</li>
                <li className="flex items-center gap-2"><Check className="w-4 h-4 text-emerald-400" /> Cupons de desconto para suas clientes</li>
                <li className="flex items-center gap-2"><Check className="w-4 h-4 text-emerald-400" /> Certificado Digital de Parceira Oficial</li>
                <li className="flex items-center gap-2"><Check className="w-4 h-4 text-emerald-400" /> Vídeos de treinamento de vendas</li>
              </ul>
            </div>
            <div className="pt-6">
              <span className="text-xxs uppercase tracking-wider text-white/40 font-bold block mb-1">Requisito</span>
              <p className="text-sm font-bold text-[#C59B5F]">Completar cadastro comercial (CNPJ/MEI)</p>
            </div>
          </div>

          {/* Gold Card */}
          <div className="bg-[#1a1a1a] border border-[#b0874e]/30 rounded-2xl p-8 text-left space-y-6 shadow-2xl hover:border-[#C59B5F] transition-all duration-300 relative flex flex-col justify-between">
            <div className="space-y-4">
              <div className="w-12 h-12 bg-[#C59B5F]/20 rounded-full flex items-center justify-center text-[#C59B5F]">
                <Crown className="w-6 h-6 animate-pulse" />
              </div>
              <h3 className="text-xl font-serif font-bold text-[#C59B5F] flex items-center justify-between">
                Gold Reseller <span className="text-xs px-2 py-0.5 rounded bg-white/10 text-[#C59B5F] font-sans font-normal uppercase tracking-wider">Elite</span>
              </h3>
              <p className="text-white/60 text-sm font-light leading-relaxed">
                Elite de vendas. O topo do ecossistema com assessoria VIP e tráfego pago compartilhado.
              </p>
              <ul className="space-y-2.5 text-xs text-white/75 pt-4 border-t border-white/5">
                <li className="flex items-center gap-2"><Check className="w-4 h-4 text-emerald-400" /> Todos os benefícios do Silver</li>
                <li className="flex items-center gap-2"><Check className="w-4 h-4 text-emerald-400" /> **+5% de Desconto Extra Fixo** na sacola</li>
                <li className="flex items-center gap-2"><Check className="w-4 h-4 text-emerald-400" /> Frete grátis/subsídio em campanhas</li>
                <li className="flex items-center gap-2"><Check className="w-4 h-4 text-emerald-400" /> Download de fotos e vídeos originais</li>
                <li className="flex items-center gap-2"><Check className="w-4 h-4 text-emerald-400" /> Atendimento direto da assistente Lia AI</li>
                <li className="flex items-center gap-2"><Check className="w-4 h-4 text-emerald-400" /> Acesso antecipado a coleções exclusivas</li>
                <li className="flex items-center gap-2"><Check className="w-4 h-4 text-emerald-400" /> Participação em tráfego patrocinado local</li>
                <li className="flex items-center gap-2"><Check className="w-4 h-4 text-emerald-400" /> Destaque no ranking nacional da marca</li>
                <li className="flex items-center gap-2"><Check className="w-4 h-4 text-emerald-400" /> Selo "Gold Elite" no cabeçalho do site</li>
              </ul>
            </div>
            <div className="pt-6">
              <span className="text-xxs uppercase tracking-wider text-white/40 font-bold block mb-1">Requisito</span>
              <p className="text-sm font-bold text-[#C59B5F]">R$ 3.000 acumulados em compras</p>
            </div>
          </div>

        </div>
      </section>

      {/* SECTION 4: THE PRIVATE PORTAL TEASER (Background updated to light rose cream #fff8f5 per user request) */}
      <section className="py-20 bg-[#fff8f5] border-y border-[#b0874e]/20 text-[#2C1E1A] relative overflow-hidden">
        <div className="absolute top-0 left-0 w-96 h-96 bg-[#C59B5F]/5 rounded-full filter blur-3xl transform -translate-x-1/2 -translate-y-1/2" />
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-[#C59B5F]/5 rounded-full filter blur-3xl transform translate-x-1/2 translate-y-1/2" />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">

          <div className="lg:col-span-7 space-y-6 text-left">
            <span className="text-[#b0874e] text-xs font-bold uppercase tracking-wider">Apoio Tecnológico Inédito</span>
            <h2 className="text-3xl sm:text-4xl font-serif font-bold leading-tight text-[#2C1E1A]">
              Um "App" Privado para turbinar suas vendas e faturar mais
            </h2>
            <p className="text-[#5C4D4A] font-light text-base leading-relaxed">
              Diferente de qualquer confecção comum, as parceiras comerciais da Avante Lingerie ganham acesso gratuito a um <strong>Portal de Membros</strong> fechado, equipped com ferramentas de automação que poupam seu tempo e aumentam sua conversão de vendas diárias.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 pt-4">

              <div className="flex gap-4">
                <div className="w-10 h-10 rounded-lg bg-[#1a1a1a] flex items-center justify-center text-[#C59B5F] shrink-0 shadow-md">
                  <Download className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-sm text-[#2C1E1A]">Central de Mídias 100% Livre</h4>
                  <p className="text-xs text-[#5C4D4A] mt-1">Baixe pacotes compactados de fotos e Reels profissionais de alta definição em 1 clique.</p>
                </div>
              </div>

              <div className="flex gap-4">
                <div className="w-10 h-10 rounded-lg bg-[#1a1a1a] flex items-center justify-center text-[#C59B5F] shrink-0 shadow-md">
                  <Smartphone className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-sm text-[#2C1E1A]">Precificadora Inteligent</h4>
                  <p className="text-xs text-[#5C4D4A] mt-1">Coloque o preço pago, configure desconto do Pix/parcelas e copie a oferta formatada.</p>
                </div>
              </div>

              <div className="flex gap-4">
                <div className="w-10 h-10 rounded-lg bg-[#1a1a1a] flex items-center justify-center text-[#C59B5F] shrink-0 shadow-md">
                  <Check className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-sm text-[#2C1E1A]">Kits Iniciais Inteligentes</h4>
                  <p className="text-xs text-[#5C4D4A] mt-1">Sugerimos o seu lote ideal com base nas cores e tamanhos mais vendidos do e-commerce na semana.</p>
                </div>
              </div>

              <div className="flex gap-4">
                <div className="w-10 h-10 rounded-lg bg-[#1a1a1a] flex items-center justify-center text-[#C59B5F] shrink-0 shadow-md">
                  <Users className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-sm text-[#2C1E1A]">Sua Franquia Digital</h4>
                  <p className="text-xs text-[#5C4D4A] mt-1">Gere o catálogo oficial em PDF contendo seus próprios dados e telefone no cabeçalho em 5 segundos.</p>
                </div>
              </div>

            </div>
          </div>

          {/* Interactive Portal Preview Mockup remains beautifully dark as requested */}
          <div className="lg:col-span-5 relative flex justify-center z-10">
            <div className="bg-[#1a1a1a] border border-[#b0874e]/30 rounded-3xl p-6 w-full max-w-[380px] shadow-2xl relative text-white">
              <div className="flex items-center justify-between border-b border-white/10 pb-4 mb-6">
                <div className="flex items-center gap-2">
                  <Crown className="w-5 h-5 text-[#C59B5F]" />
                  <span className="font-bold text-xs uppercase tracking-wider text-white">Central B2B</span>
                </div>
                <span className="text-[10px] bg-emerald-500/10 text-emerald-400 px-2 py-0.5 rounded-full font-bold uppercase">Sessão Gold</span>
              </div>

              <div className="space-y-6">
                <div className="space-y-2">
                  <p className="text-[10px] text-white/50 uppercase font-semibold">Ferramenta Rápida</p>
                  <div className="bg-white/5 rounded-xl p-4 border border-white/5">
                    <h5 className="font-bold text-xs text-white">Precificadora de WhatsApp</h5>

                    <div className="mt-4 space-y-3">
                      <div className="flex justify-between text-[11px] text-white/60">
                        <span>Custo Pago: R$ 25,00</span>
                        <span>Margem: 120%</span>
                      </div>
                      <div className="h-1 bg-white/10 rounded-full overflow-hidden">
                        <div className="w-1/2 h-full bg-[#C59B5F]" />
                      </div>
                      <div className="bg-white/5 rounded-lg p-2 flex justify-between items-center border border-white/5">
                        <span className="text-[10px] text-white/40">WhatsApp Copy</span>
                        <Copy className="w-3.5 h-3.5 text-[#C59B5F] cursor-pointer" />
                      </div>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <p className="text-[10px] text-white/50 uppercase font-semibold">Material Recente</p>
                  <div className="flex items-center justify-between bg-white/5 rounded-xl p-3 border border-white/5">
                    <div className="flex items-center gap-2">
                      <Download className="w-4 h-4 text-emerald-400" />
                      <span className="text-xs text-white/80 font-bold">Fotos Satin Gold 2026.zip</span>
                    </div>
                    <span className="text-[10px] text-white/40">45 MB</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

        </div>
      </section>

      {/* SECTION 5: CONTACT CAPTURE FORM */}
      <section id="cadastro" className="py-20 scroll-mt-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-12">

          <div className="max-w-2xl mx-auto space-y-4">
            <span className="text-[#C59B5F] text-xs font-bold uppercase tracking-wider">Garanta sua Oportunidade</span>
            <h2 className="text-3xl sm:text-4xl font-serif font-bold text-white">
              Dê o primeiro passo rumo à independência
            </h2>
            <p className="text-white/60 font-light">
              Preencha o pré-cadastro com seus dados de contato comerciais. Nosso time analisará seu perfil rapidamente e liberará as credenciais de seu Portal.
            </p>
          </div>

          <div className="max-w-xl mx-auto bg-[#1a1a1a] border border-[#b0874e]/30 p-8 md:p-10 rounded-3xl shadow-2xl relative">

            {submitSuccess ? (
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="text-center py-10 space-y-6"
              >
                <div className="w-16 h-16 bg-emerald-500/10 text-emerald-400 rounded-full flex items-center justify-center mx-auto shadow-sm">
                  <CheckCircle2 className="w-10 h-10" />
                </div>
                <h3 className="text-2xl font-serif font-bold text-white">Parabéns! Pré-cadastro realizado!</h3>
                <p className="text-white/70 text-sm font-light leading-relaxed max-w-sm mx-auto">
                  Seus dados comerciais foram gravados na nossa fila com sucesso.
                  Enviamos as instruções para o seu e-mail e nosso gerente de contas VIP entrará em contato via WhatsApp nas próximas horas. Seja muito bem-vinda!
                </p>
              </motion.div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-6 text-left">
                <div className="space-y-2">
                  <label className="text-xs font-bold uppercase tracking-wider text-white/60">Nome Completo</label>
                  <input
                    type="text"
                    name="nome"
                    value={formData.nome}
                    onChange={handleInputChange}
                    placeholder="Seu nome completo"
                    className="w-full px-4 py-3.5 border border-white/10 focus:border-[#C59B5F] rounded-xl outline-none transition-colors bg-[#262626] text-white"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-bold uppercase tracking-wider text-white/60">WhatsApp / Celular comercial</label>
                  <input
                    type="tel"
                    name="whatsapp"
                    value={formData.whatsapp}
                    onChange={handleInputChange}
                    placeholder="(00) 90000-0000"
                    className="w-full px-4 py-3.5 border border-white/10 focus:border-[#C59B5F] rounded-xl outline-none transition-colors bg-[#262626] text-white"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-bold uppercase tracking-wider text-white/60">Seu E-mail principal</label>
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    placeholder="exemplo@gmail.com"
                    className="w-full px-4 py-3.5 border border-white/10 focus:border-[#C59B5F] rounded-xl outline-none transition-colors bg-[#262626] text-white"
                    required
                  />
                </div>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full py-4 bg-[#C59B5F] hover:bg-[#b0874e] text-black font-extrabold text-xs uppercase tracking-wider rounded-xl transition-all duration-300 shadow-md flex items-center justify-center gap-3 disabled:opacity-50"
                >
                  {isSubmitting ? 'Gravando no sistema...' : 'Enviar Pré-Cadastro & Simulação'}
                  <ArrowRight className="w-4 h-4" />
                </button>

                <p className="text-xxs text-white/40 text-center leading-normal">
                  Ao enviar, você declara que está de acordo com as diretrizes de LGPD e políticas comerciais da Avante Lingerie para comércio de moda íntima.
                </p>
              </form>
            )}

          </div>

        </div>
      </section>

      {/* SECTION 6: FAQ ACCORDION */}
      <section className="py-16 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-12">
        <div className="space-y-4">
          <span className="text-[#C59B5F] text-xs font-bold uppercase tracking-wider">Perguntas Frequentes</span>
          <h2 className="text-3xl font-serif font-bold text-white">Tire Suas Dúvidas Rápidas</h2>
        </div>

        <div className="space-y-4 text-left">
          {faqData.map((item, idx) => {
            const isOpen = openFaqIndex === idx;
            return (
              <div
                key={idx}
                className="bg-[#1a1a1a] border border-[#b0874e]/30 rounded-2xl overflow-hidden shadow-2xl transition-all duration-300"
              >
                <button
                  type="button"
                  onClick={() => setOpenFaqIndex(isOpen ? null : idx)}
                  className="w-full px-6 py-5 flex items-center justify-between text-left font-bold text-sm text-white gap-4"
                >
                  <span className="flex items-center gap-3"><HelpCircle className="w-4 h-4 text-[#C59B5F] shrink-0" /> {item.q}</span>
                  <span className={`text-xs text-[#C59B5F] transition-transform duration-300 \${isOpen ? 'rotate-180' : ''}`}>▼</span>
                </button>

                <AnimatePresence initial={false}>
                  {isOpen && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.25 }}
                      className="border-t border-white/5"
                    >
                      <div className="px-6 py-5 text-white/70 text-xs font-light leading-relaxed">
                        {item.a}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            );
          })}
        </div>
      </section>

    </div>
  );
}