import React from 'react';
import { Helmet } from 'react-helmet';
import { useNavigate, Link } from 'react-router-dom';
import { Lock, Shield, UserCircle, Truck, CreditCard, ChevronRight, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button.jsx';
import { Switch } from '@/components/ui/switch.jsx';
import { Label } from '@/components/ui/label.jsx';
import { toast } from 'sonner';

import { useCheckoutLogic } from '@/hooks/useCheckoutLogic.js';
import CheckoutAddressForm from '@/components/CheckoutAddressForm.jsx';
import CheckoutOrderSummary from '@/components/CheckoutOrderSummary.jsx';
import CheckoutMicroOffer from '@/components/CheckoutMicroOffer.jsx';

export default function Checkout() {
  const navigate = useNavigate();
  const {
    currentUser,
    cart,
    subtotal,
    finalTotal,
    finalDiscountAmount,
    activeBenefitMessage,
    benefitType,
    billingAddress,
    deliveryAddress,
    isSameAddress,
    setIsSameAddress,
    handleAddressChange,
    handleCepBlur,
    loadingCep,
    paymentMethod,
    setPaymentMethod,
    shippingCost,
    removeFromCart,
    isSubmitting,
    finalizeOrder,
    getItemPrice,
    limiteUpgrade
  } = useCheckoutLogic();

  const isReseller = currentUser?.commercial_profile === 'reseller' || currentUser?.tipo_cliente === 'revendedor';
  const showWholesaleLock = isReseller && subtotal < limiteUpgrade;

  // High #18: Redirect to store after 3s if cart is empty, avoiding static stranded UX
  React.useEffect(() => {
    if (cart.length === 0) {
      toast.info('Seu carrinho está vazio. Redirecionando para as nossas coleções...');
      const timer = setTimeout(() => {
        navigate('/');
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [cart, navigate]);

  const handleFinalizeOrder = async () => {
    const orderId = await finalizeOrder();
    if (orderId) {
      navigate(`/order-confirmation/${orderId}`);
    }
  };

  if (cart.length === 0) {
    return (
      <div className="min-h-[80vh] flex flex-col items-center justify-center text-center p-4 bg-[#FFFBF8] font-sans">
        <h1 className="text-3xl font-serif font-bold text-gray-900 mb-6">Seu carrinho está vazio</h1>
        <p className="text-gray-400 text-xs font-light mb-6">Estamos te levando de volta para a nossa vitrine de lançamentos...</p>
        <Button
          onClick={() => navigate('/')}
          className="bg-[#121212] hover:bg-[#c59b5f] text-white hover:text-black border border-[#c59b5f]/30 rounded-2xl px-10 py-6 text-xs font-bold tracking-widest uppercase transition-all duration-300 shadow-md active:scale-95 animate-pulse"
        >
          Voltar para a loja
        </Button>
      </div>
    );
  }

  return (
    <main className="min-h-screen bg-[#FFFBF8] pb-24 text-gray-800 font-sans">
      <Helmet>
        <title>Finalizar Compra | Avante Lingerie</title>
      </Helmet>

      {/* LUXURY GLOWING TOP BANNER */}
      <div className="bg-gradient-to-br from-[#121212] via-[#1a1a1a] to-[#0a0a0a] pt-28 pb-12 px-4 sm:px-6 relative overflow-hidden shadow-premium border-b border-[#c59b5f]/15">
        <div className="absolute inset-0 bg-[url('https://horizons-cdn.hostinger.com/2863a2ab-708d-40c9-b019-44d46f1b8bc1/32a1bb1a0ab84a2ba361f1c75c87c712.png')] opacity-[0.04] mix-blend-overlay"></div>
        {/* Decorative elements */}
        <div className="absolute -top-40 -right-40 w-96 h-96 bg-[#c59b5f]/5 rounded-full blur-[100px] pointer-events-none"></div>
        <div className="absolute -bottom-40 -left-40 w-96 h-96 bg-[#c59b5f]/5 rounded-full blur-[100px] pointer-events-none"></div>

        <div className="max-w-6xl mx-auto relative z-10 flex flex-col items-center justify-center gap-6">
          <div className="flex items-center gap-2 text-white/50 text-xs w-full justify-center font-medium">
            <Link to="/cart" className="hover:text-[#c59b5f] transition-colors">Carrinho</Link>
            <ChevronRight className="w-3 h-3 text-[#c59b5f]/50" />
            <span className="text-[#c59b5f] font-bold">Pagamento Seguro</span>
          </div>

          <div className="flex flex-col items-center justify-center text-center">
            <h1 className="text-2.5xl md:text-3.5xl font-serif font-bold text-white flex items-center justify-center gap-3.5">
              <div className="relative w-10 h-10 flex items-center justify-center shrink-0 select-none">
                {/* Gold seal body with radial gold gradients */}
                <div className="absolute inset-0 rounded-full bg-gradient-to-r from-[#b3864b] via-[#e5c595] to-[#b3864b] p-[1.5px] shadow-[0_0_12px_rgba(197,155,95,0.4)]">
                  <div className="w-full h-full rounded-full bg-[#121212] flex items-center justify-center relative">
                    {/* Dashed certificate line */}
                    <div className="absolute inset-[2px] rounded-full border border-dashed border-[#c59b5f]/35"></div>
                    <Lock className="w-4.5 h-4.5 text-[#e5c595]" strokeWidth={2} />
                  </div>
                </div>
                {/* Tiny glowing dot representing premium active security */}
                <span className="absolute -top-0.5 -right-0.5 w-2.5 h-2.5 bg-emerald-500 rounded-full border-2 border-[#121212] shadow-sm animate-ping"></span>
                <span className="absolute -top-0.5 -right-0.5 w-2.5 h-2.5 bg-emerald-500 rounded-full border-2 border-[#121212] shadow-sm"></span>
              </div>
              Finalização Segura
            </h1>
            <p className="text-white/70 text-xs md:text-sm mt-2.5 font-light">Ambiente de segurança máxima com criptografia SSL ativa. Seus dados estão 100% protegidos.</p>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 sm:px-6 mt-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12">

          <div className="lg:col-span-7 flex flex-col gap-8">

            {showWholesaleLock && (
              <div className="bg-red-50 border border-red-200 rounded-3xl p-6 md:p-8 shadow-sm flex flex-col sm:flex-row items-center justify-between gap-4 transition-all duration-300">
                <div className="flex gap-4 items-start">
                  <span className="text-red-500 text-2xl">⚠️</span>
                  <div className="flex-1">
                    <h4 className="font-bold text-red-900 text-sm uppercase">Pedido abaixo do mínimo de atacado</h4>
                    <p className="text-xs text-red-700 mt-1 leading-relaxed">
                      Como revendedora oficial, o valor mínimo do seu pedido de atacado deve ser de <strong>R$ {limiteUpgrade.toFixed(2)}</strong>.
                      Seu carrinho atual é de <strong>R$ {subtotal.toFixed(2)}</strong>. Por favor, retorne ao carrinho para completar seu pedido ou alterar para varejo.
                    </p>
                    <div className="flex flex-wrap gap-3 mt-4">
                      <Button
                        onClick={() => navigate('/cart')}
                        className="bg-[#3A2E2A] hover:bg-[#2A1E1A] text-white text-xs font-bold uppercase tracking-wider px-5 py-2.5 rounded-xl h-auto"
                      >
                        Voltar ao Carrinho
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* IDENTIFICATION SECTION */}
            <div className="bg-white border border-[#c59b5f]/15 border-l-4 border-l-[#c59b5f] rounded-3xl p-6 md:p-8 shadow-premium-sm flex flex-col sm:flex-row items-center justify-between gap-4 transition-all duration-300 hover:shadow-[0_12px_30px_rgba(197,155,95,0.04)]">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full bg-[#c59b5f]/10 border border-[#c59b5f]/20 flex items-center justify-center text-[#c59b5f]">
                  <UserCircle className="w-6 h-6" strokeWidth={1.5} />
                </div>
                <div>
                  {currentUser ? (
                    <>
                      <h2 className="text-base md:text-lg font-serif font-bold text-gray-950">Bem-vinda de volta, {currentUser.name || currentUser.nome_completo || 'Cliente'}!</h2>
                      <p className="text-xs text-gray-400 font-light mt-0.5">Você está autenticada com o e-mail: <strong>{currentUser.email}</strong>.</p>
                    </>
                  ) : (
                    <>
                      <h2 className="text-base md:text-lg font-serif font-bold text-gray-950">Identificação</h2>
                      <p className="text-xs text-gray-400 font-light mt-0.5">Faça login para uma experiência de compra mais rápida.</p>
                    </>
                  )}
                </div>
              </div>
              {!currentUser && (
                <Button
                  variant="outline"
                  onClick={() => navigate('/login')}
                  className="w-full sm:w-auto border border-[#c59b5f]/30 text-gray-800 hover:bg-[#121212] hover:text-white rounded-2xl py-5 text-xs font-bold tracking-widest uppercase transition-all duration-300"
                >
                  Fazer Login
                </Button>
              )}
            </div>

            {/* BILLING ADDRESS SECTION */}
            <CheckoutAddressForm
              type="billing"
              title="Endereço de Faturamento"
              data={billingAddress}
              onChange={handleAddressChange}
              onCepBlur={handleCepBlur}
              isLoading={loadingCep.billing}
            />

            {/* TOGGLE SAME ADDRESS SECTION */}
            <div className="bg-white border border-[#c59b5f]/15 rounded-3xl p-6 md:p-8 shadow-premium-sm flex flex-col gap-4 transition-all duration-300 hover:shadow-[0_12px_30px_rgba(197,155,95,0.04)]">
              <div className="flex items-center justify-between gap-4">
                <div className="flex flex-col">
                  <Label htmlFor="same-address-toggle" className="text-base font-serif font-bold text-gray-950 cursor-pointer">
                    Endereço de Entrega
                  </Label>
                  <span className="text-xs text-gray-400 font-light mt-0.5">O pedido será entregue no mesmo endereço de faturamento?</span>
                </div>
                <Switch
                  id="same-address-toggle"
                  checked={isSameAddress}
                  onCheckedChange={setIsSameAddress}
                  className="data-[state=checked]:bg-[#c59b5f]"
                />
              </div>

              {!isSameAddress && (
                <div className="pt-6 border-t border-gray-100 mt-2">
                  <CheckoutAddressForm
                    type="delivery"
                    title="Onde devemos entregar?"
                    data={deliveryAddress}
                    onChange={handleAddressChange}
                    onCepBlur={handleCepBlur}
                    isLoading={loadingCep.delivery}
                  />
                </div>
              )}
            </div>

            {/* SHIPPING OPTIONS SECTION */}
            <div className="bg-white border border-[#c59b5f]/15 rounded-3xl p-6 md:p-8 shadow-premium-sm flex flex-col gap-4 transition-all duration-300 hover:shadow-[0_12px_30px_rgba(197,155,95,0.04)] opacity-70 cursor-not-allowed">
              <div className="flex items-center gap-2 mb-2">
                <div className="w-8 h-8 rounded-full bg-[#c59b5f]/10 border border-[#c59b5f]/20 flex items-center justify-center text-[#c59b5f]">
                  <Truck className="w-4 h-4" strokeWidth={1.5} />
                </div>
                <h3 className="text-base font-serif font-bold text-gray-950">Opções de Frete</h3>
              </div>
              <div className="bg-[#FFFBF8] p-5 rounded-2xl text-center text-xs text-gray-400 border border-dashed border-[#c59b5f]/25 font-light">
                Opções de envio e cálculo de frete serão exibidos aqui de forma automática via Melhor Envio.
              </div>
            </div>

            {/* PAYMENT METHODS SECTION */}
            <div className="bg-white border border-[#c59b5f]/15 rounded-3xl p-6 md:p-8 shadow-premium-sm flex flex-col transition-all duration-300 hover:shadow-[0_12px_30px_rgba(197,155,95,0.04)]">
              <div className="flex items-center gap-2 mb-6">
                <div className="w-8 h-8 rounded-full bg-[#c59b5f]/10 border border-[#c59b5f]/20 flex items-center justify-center text-[#c59b5f]">
                  <CreditCard className="w-4 h-4" strokeWidth={1.5} />
                </div>
                <h3 className="text-base font-serif font-bold text-gray-950">Forma de Pagamento</h3>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div
                  onClick={() => !isSubmitting && setPaymentMethod('credit_card')}
                  className={`border-2 rounded-2xl p-6 cursor-pointer transition-all duration-300 ${isSubmitting ? 'cursor-not-allowed opacity-60' : ''} ${paymentMethod === 'credit_card' ? 'border-[#c59b5f] bg-[#c59b5f]/5 shadow-premium-sm scale-[1.01]' : 'border-gray-100 hover:border-[#c59b5f]/30 hover:bg-[#FFFBF8]'}`}
                >
                  <div className="flex items-center gap-3">
                    <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center transition-colors ${paymentMethod === 'credit_card' ? 'border-[#c59b5f]' : 'border-gray-300'}`}>
                      {paymentMethod === 'credit_card' && <div className="w-2.5 h-2.5 rounded-full bg-[#c59b5f]" />}
                    </div>
                    <span className="font-bold text-gray-900 text-sm tracking-wide">Cartão de Crédito</span>
                  </div>
                  <p className="text-xs text-gray-400 font-light mt-2 ml-8">Até 6x sem juros</p>
                </div>

                <div
                  onClick={() => !isSubmitting && setPaymentMethod('pix')}
                  className={`border-2 rounded-2xl p-6 cursor-pointer transition-all duration-300 ${isSubmitting ? 'cursor-not-allowed opacity-60' : ''} ${paymentMethod === 'pix' ? 'border-[#c59b5f] bg-[#c59b5f]/5 shadow-premium-sm scale-[1.01]' : 'border-gray-100 hover:border-[#c59b5f]/30 hover:bg-[#FFFBF8]'}`}
                >
                  <div className="flex items-center gap-3">
                    <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center transition-colors ${paymentMethod === 'pix' ? 'border-[#c59b5f]' : 'border-gray-300'}`}>
                      {paymentMethod === 'pix' && <div className="w-2.5 h-2.5 rounded-full bg-[#c59b5f]" />}
                    </div>
                    <span className="font-bold text-gray-900 text-sm tracking-wide">PIX</span>
                  </div>
                  <p className="text-xs text-[#c59b5f] font-extrabold mt-2 ml-8 uppercase tracking-widest">5% de Desconto Extra</p>
                </div>
              </div>

              <div className="bg-[#FFFBF8] p-5 rounded-2xl text-center text-xs text-gray-400 border border-dashed border-[#c59b5f]/25 font-light mt-6 opacity-70">
                Formulário de pagamento seguro integrado com a plataforma de pagamentos Stripe.
              </div>
            </div>

          </div>

          {/* STICKY ORDER SUMMARY COLUMN */}
          <div className="lg:col-span-5 relative">
            <div className="sticky top-28 flex flex-col">

              <CheckoutMicroOffer />

              <CheckoutOrderSummary
                cart={cart}
                subtotal={subtotal}
                finalTotal={finalTotal}
                finalDiscountAmount={finalDiscountAmount}
                activeBenefitMessage={activeBenefitMessage}
                benefitType={benefitType}
                shippingCost={shippingCost}
                onRemove={removeFromCart}
                getItemPrice={getItemPrice}
              />

              <Button
                size="lg"
                onClick={handleFinalizeOrder}
                disabled={isSubmitting || showWholesaleLock}
                className="w-full mt-6 bg-[#121212] hover:bg-[#c59b5f] text-white hover:text-black border border-[#c59b5f]/30 rounded-2xl py-7.5 text-xs font-bold tracking-widest uppercase transition-all duration-300 shadow-xl active:scale-[0.98] flex items-center justify-center disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isSubmitting ? (
                  <Loader2 className="w-4 h-4 mr-2 text-[#c59b5f] animate-spin" />
                ) : (
                  <Lock className="w-4 h-4 mr-2 text-[#c59b5f] group-hover:text-black transition-colors" />
                )}
                {isSubmitting ? 'PROCESSANDO PEDIDO...' : showWholesaleLock ? 'MÍNIMO DE ATACADO NÃO ATINGIDO' : 'CONCLUIR COMPRA'}
              </Button>

              {/* SECURITY CERTIFICATE BADGES */}
              <div className="flex items-center justify-center gap-4 mt-6 flex-wrap">
                <div className="flex items-center gap-2 border border-[#c59b5f]/20 bg-[#c59b5f]/5 text-gray-800 px-4 py-2.5 rounded-xl text-[10px] font-bold uppercase tracking-wider shadow-premium-sm">
                  <Shield className="w-4 h-4 text-[#c59b5f]" strokeWidth={1.5} /> 100% Seguro
                </div>
                <div className="flex items-center gap-2 border border-[#c59b5f]/20 bg-[#c59b5f]/5 text-gray-800 px-4 py-2.5 rounded-xl text-[10px] font-bold uppercase tracking-wider shadow-premium-sm">
                  <Lock className="w-4 h-4 text-[#c59b5f]" strokeWidth={1.5} /> Criptografia SSL
                </div>
              </div>

            </div>
          </div>

        </div>
      </div>
    </main>
  );
}