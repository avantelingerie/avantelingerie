import React, { useState, useEffect } from 'react';
import { Link2, Key, CheckCircle2, XCircle, AlertCircle, Eye, EyeOff, Loader2, RefreshCw, Save, Sparkles, MessageSquare, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button.jsx';
import { Input } from '@/components/ui/input.jsx';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { toast } from 'sonner';
import apiServerClient from '@/lib/apiServerClient.js';
import pb from '@/lib/pocketbaseClient.js';

export default function IntegracoesList() {
  const [status, setStatus] = useState({
    bling: { status: 'nao_configurado', ultimo_teste: null },
    stripe: { status: 'nao_configurado', ultimo_teste: null },
    melhor_envio: { status: 'nao_configurado', ultimo_teste: null },
    gemini: { status: 'nao_configurado', ultimo_teste: null },
    whatsapp: { status: 'nao_configurado', ultimo_teste: null }
  });
  const [isLoading, setIsLoading] = useState(true);
  const [isTesting, setIsTesting] = useState({});
  const [isSaving, setIsSaving] = useState({});
  const [showKeys, setShowKeys] = useState({});

  const [keys, setKeys] = useState({
    stripe_pk_live: '',
    stripe_sk_live: '',
    stripe_webhook_secret: '',
    melhor_envio_token: '',
    gemini_api_key: '',
    whatsapp_token: ''
  });

  const fetchStatus = async () => {
    try {
      const res = await apiServerClient.fetch('/integracoes/status');
      if (res.ok) {
        const data = await res.json();
        setStatus(prev => ({ ...prev, ...data }));
      }
    } catch (error) {
      console.error('Erro ao buscar status das integrações:', error);
      toast.error('Não foi possível carregar o status das integrações.');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchStatus();
  }, []);

  const handleSaveDb = async (servico, chave_nome, chave_valor) => {
    if (!chave_valor) return;
    setIsSaving(prev => ({ ...prev, [servico]: true }));
    try {
      const res = await apiServerClient.fetch('/integracoes/salvar', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          servico,
          chave_nome,
          chave_valor,
          ambiente: 'producao'
        })
      });

      if (!res.ok) throw new Error('Falha ao salvar no servidor');

      toast.success(`Configurações de ${servico} salvas com sucesso!`);
      setKeys(prev => ({ ...prev, [`${servico}_${chave_nome === 'api_key' ? 'api_key' : 'token'}`]: '' }));
      fetchStatus();
    } catch (error) {
      console.error(error);
      toast.error(`Erro ao salvar configurações de ${servico}.`);
    } finally {
      setIsSaving(prev => ({ ...prev, [servico]: false }));
    }
  };

  const handleClearDb = async (servico, chave_nome) => {
    if (!window.confirm(`Tem certeza que deseja apagar a chave de ${servico}? Esta ação removerá a chave do banco de dados.`)) {
      return;
    }
    setIsSaving(prev => ({ ...prev, [servico]: true }));
    try {
      const res = await apiServerClient.fetch('/integracoes/limpar', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          servico,
          chave_nome
        })
      });

      if (!res.ok) throw new Error('Falha ao limpar no servidor');

      toast.success(`Configurações de ${servico} limpas com sucesso!`);
      fetchStatus();
    } catch (error) {
      console.error(error);
      toast.error(`Erro ao limpar configurações de ${servico}.`);
    } finally {
      setIsSaving(prev => ({ ...prev, [servico]: false }));
    }
  };

  const handleSave = async (servico, keyData) => {
    setIsSaving(prev => ({ ...prev, [servico]: true }));
    try {
      for (const [chave_nome, chave_valor] of Object.entries(keyData)) {
        if (!chave_valor) continue;
        const res = await apiServerClient.fetch('/integracoes/salvar', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            servico,
            chave_nome,
            chave_valor,
            ambiente: 'producao'
          })
        });
        if (!res.ok) throw new Error('Falha ao salvar');
      }
      toast.success(`Configurações de ${servico} salvas com sucesso!`);
      setKeys(prev => {
        const newKeys = { ...prev };
        Object.keys(keyData).forEach(k => newKeys[k] = '');
        return newKeys;
      });
      fetchStatus();
    } catch (error) {
      toast.error(`Erro ao salvar configurações de ${servico}.`);
    } finally {
      setIsSaving(prev => ({ ...prev, [servico]: false }));
    }
  };

  const handleTest = async (servico) => {
    setIsTesting(prev => ({ ...prev, [servico]: true }));
    try {
      const res = await apiServerClient.fetch(`/integracoes/testar/${servico}`, { method: 'POST' });
      const data = await res.json();
      if (data.sucesso) {
        toast.success(`Conexão com ${servico} bem-sucedida!`);
      } else {
        toast.error(`Falha na conexão com ${servico}: ${data.mensagem}`);
      }
      fetchStatus();
    } catch (error) {
      toast.error(`Erro ao testar conexão com ${servico}.`);
    } finally {
      setIsTesting(prev => ({ ...prev, [servico]: false }));
    }
  };

  const toggleShowKey = (keyName) => {
    setShowKeys(prev => ({ ...prev, [keyName]: !prev[keyName] }));
  };

  const StatusBadge = ({ statusData }) => {
    if (statusData?.status === 'conectado') {
      return <Badge className="bg-emerald-500/10 text-emerald-600 hover:bg-emerald-500/20 border-emerald-200"><CheckCircle2 className="w-3 h-3 mr-1" /> Conectado</Badge>;
    }
    if (statusData?.status === 'erro') {
      return <Badge variant="destructive" className="bg-red-500/10 text-red-600 hover:bg-red-500/20 border-red-200"><XCircle className="w-3 h-3 mr-1" /> Erro</Badge>;
    }
    return <Badge variant="outline" className="text-muted-foreground"><AlertCircle className="w-3 h-3 mr-1" /> Não Testado</Badge>;
  };

  if (isLoading) {
    return <div className="flex items-center justify-center h-64"><Loader2 className="w-8 h-8 animate-spin text-primary" /></div>;
  }

  return (
    <div className="max-w-5xl mx-auto space-y-8">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Integrações</h1>
        <p className="text-muted-foreground mt-2">Gerencie as conexões com serviços externos (Pagamentos, ERP, Logística).</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Stripe Card */}
        <Card className="shadow-sm">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-[#635BFF]/10 flex items-center justify-center">
                  <Key className="w-5 h-5 text-[#635BFF]" />
                </div>
                <div>
                  <CardTitle>Stripe</CardTitle>
                  <CardDescription>Gateway de Pagamentos</CardDescription>
                </div>
              </div>
              <StatusBadge statusData={status.stripe} />
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Publishable Key (pk_live)</label>
              <div className="relative">
                <Input 
                  type={showKeys.stripe_pk_live ? "text" : "password"} 
                  placeholder="pk_live_..." 
                  value={keys.stripe_pk_live}
                  onChange={e => setKeys({...keys, stripe_pk_live: e.target.value})}
                  className="pr-10"
                />
                <button type="button" onClick={() => toggleShowKey('stripe_pk_live')} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground">
                  {showKeys.stripe_pk_live ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Secret Key (sk_live)</label>
              <div className="relative">
                <Input 
                  type={showKeys.stripe_sk_live ? "text" : "password"} 
                  placeholder="sk_live_..." 
                  value={keys.stripe_sk_live}
                  onChange={e => setKeys({...keys, stripe_sk_live: e.target.value})}
                  className="pr-10"
                />
                <button type="button" onClick={() => toggleShowKey('stripe_sk_live')} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground">
                  {showKeys.stripe_sk_live ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Webhook Secret (whsec)</label>
              <div className="relative">
                <Input 
                  type={showKeys.stripe_webhook_secret ? "text" : "password"} 
                  placeholder="whsec_..." 
                  value={keys.stripe_webhook_secret}
                  onChange={e => setKeys({...keys, stripe_webhook_secret: e.target.value})}
                  className="pr-10"
                />
                <button type="button" onClick={() => toggleShowKey('stripe_webhook_secret')} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground">
                  {showKeys.stripe_webhook_secret ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>
            {status.stripe?.ultimo_teste && (
              <p className="text-xs text-muted-foreground">Último teste: {new Date(status.stripe.ultimo_teste).toLocaleString('pt-BR')}</p>
            )}
          </CardContent>
          <CardFooter className="flex justify-between border-t pt-4 bg-muted/20">
            <Button variant="outline" onClick={() => handleTest('stripe')} disabled={isTesting.stripe}>
              {isTesting.stripe ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <RefreshCw className="w-4 h-4 mr-2" />}
              Testar Conexão
            </Button>
            <Button onClick={() => handleSave('stripe', { pk_live: keys.stripe_pk_live, sk_live: keys.stripe_sk_live, webhook_secret: keys.stripe_webhook_secret })} disabled={isSaving.stripe || (!keys.stripe_pk_live && !keys.stripe_sk_live && !keys.stripe_webhook_secret)}>
              {isSaving.stripe ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Save className="w-4 h-4 mr-2" />}
              Salvar
            </Button>
          </CardFooter>
        </Card>

        {/* Melhor Envio Card */}
        <Card className="shadow-sm">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-blue-500/10 flex items-center justify-center">
                  <Link2 className="w-5 h-5 text-blue-600" />
                </div>
                <div>
                  <CardTitle>Melhor Envio</CardTitle>
                  <CardDescription>Logística e Fretes</CardDescription>
                </div>
              </div>
              <StatusBadge statusData={status.melhor_envio} />
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Token de Acesso (Bearer)</label>
              <div className="relative">
                <Input 
                  type={showKeys.melhor_envio_token ? "text" : "password"} 
                  placeholder="eyJ0eXAiOiJKV1Qi..." 
                  value={keys.melhor_envio_token}
                  onChange={e => setKeys({...keys, melhor_envio_token: e.target.value})}
                  className="pr-10"
                />
                <button type="button" onClick={() => toggleShowKey('melhor_envio_token')} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground">
                  {showKeys.melhor_envio_token ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>
            {status.melhor_envio?.ultimo_teste && (
              <p className="text-xs text-muted-foreground">Último teste: {new Date(status.melhor_envio.ultimo_teste).toLocaleString('pt-BR')}</p>
            )}
          </CardContent>
          <CardFooter className="flex justify-between border-t pt-4 bg-muted/20 mt-auto">
            <Button variant="outline" onClick={() => handleTest('melhor_envio')} disabled={isTesting.melhor_envio}>
              {isTesting.melhor_envio ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <RefreshCw className="w-4 h-4 mr-2" />}
              Testar Conexão
            </Button>
            <Button onClick={() => handleSave('melhor_envio', { token: keys.melhor_envio_token })} disabled={isSaving.melhor_envio || !keys.melhor_envio_token}>
              {isSaving.melhor_envio ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Save className="w-4 h-4 mr-2" />}
              Salvar
            </Button>
          </CardFooter>
        </Card>

        {/* Google Gemini AI Card */}
        <Card className="shadow-sm">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-amber-500/10 flex items-center justify-center">
                  <Sparkles className="w-5 h-5 text-amber-600" />
                </div>
                <div>
                  <CardTitle>Google Gemini AI</CardTitle>
                  <CardDescription>Geração de Descrições Otimizadas (SEO)</CardDescription>
                </div>
              </div>
              <StatusBadge statusData={status.gemini} />
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Chave de API do Gemini (API Key)</label>
              <div className="relative">
                <Input 
                  type={showKeys.gemini_api_key ? "text" : "password"} 
                  placeholder={status.gemini?.status !== 'nao_configurado' ? "•••••••••••••••• (Configurada)" : "Cole sua chave API do Gemini aqui..."} 
                  value={keys.gemini_api_key}
                  onChange={e => setKeys({...keys, gemini_api_key: e.target.value})}
                  className="pr-10"
                />
                <button type="button" onClick={() => toggleShowKey('gemini_api_key')} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground">
                  {showKeys.gemini_api_key ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>
            {status.gemini?.ultimo_teste && (
              <p className="text-xs text-muted-foreground">Último teste: {new Date(status.gemini.ultimo_teste).toLocaleString('pt-BR')}</p>
            )}
          </CardContent>
          <CardFooter className="flex justify-between border-t pt-4 bg-muted/20">
            <div className="flex gap-2">
              <Button variant="outline" onClick={() => handleTest('gemini')} disabled={isTesting.gemini || (status.gemini?.status === 'nao_configurado' && !keys.gemini_api_key)}>
                {isTesting.gemini ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <RefreshCw className="w-4 h-4 mr-2" />}
                Testar Conexão
              </Button>
              {status.gemini?.status !== 'nao_configurado' && (
                <Button variant="ghost" className="text-red-500 hover:text-red-700 hover:bg-red-50" onClick={() => handleClearDb('gemini', 'api_key')} disabled={isSaving.gemini}>
                  <Trash2 className="w-4 h-4 mr-2" />
                  Limpar
                </Button>
              )}
            </div>
            <Button onClick={() => handleSaveDb('gemini', 'api_key', keys.gemini_api_key)} disabled={isSaving.gemini || !keys.gemini_api_key}>
              {isSaving.gemini ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Save className="w-4 h-4 mr-2" />}
              Salvar
            </Button>
          </CardFooter>
        </Card>

        {/* Lia (Site / WhatsApp) Card */}
        <Card className="shadow-sm">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-green-500/10 flex items-center justify-center">
                  <MessageSquare className="w-5 h-5 text-green-600" />
                </div>
                <div>
                  <CardTitle>Lia (Site / WhatsApp)</CardTitle>
                  <CardDescription>Assistente Virtual no WhatsApp & Vitrine</CardDescription>
                </div>
              </div>
              <StatusBadge statusData={status.whatsapp} />
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Token de Integração (API Token)</label>
              <div className="relative">
                <Input 
                  type={showKeys.whatsapp_token ? "text" : "password"} 
                  placeholder={status.whatsapp?.status !== 'nao_configurado' ? "•••••••••••••••• (Configurada)" : "Cole seu token do WhatsApp..."} 
                  value={keys.whatsapp_token}
                  onChange={e => setKeys({...keys, whatsapp_token: e.target.value})}
                  className="pr-10"
                />
                <button type="button" onClick={() => toggleShowKey('whatsapp_token')} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground">
                  {showKeys.whatsapp_token ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>
            {status.whatsapp?.ultimo_teste && (
              <p className="text-xs text-muted-foreground">Último teste: {new Date(status.whatsapp.ultimo_teste).toLocaleString('pt-BR')}</p>
            )}
          </CardContent>
          <CardFooter className="flex justify-between border-t pt-4 bg-muted/20">
            <div className="flex gap-2">
              <Button variant="outline" onClick={() => handleTest('whatsapp')} disabled={isTesting.whatsapp || (status.whatsapp?.status === 'nao_configurado' && !keys.whatsapp_token)}>
                {isTesting.whatsapp ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <RefreshCw className="w-4 h-4 mr-2" />}
                Testar Conexão
              </Button>
              {status.whatsapp?.status !== 'nao_configurado' && (
                <Button variant="ghost" className="text-red-500 hover:text-red-700 hover:bg-red-50" onClick={() => handleClearDb('whatsapp', 'token')} disabled={isSaving.whatsapp}>
                  <Trash2 className="w-4 h-4 mr-2" />
                  Limpar
                </Button>
              )}
            </div>
            <Button onClick={() => handleSaveDb('whatsapp', 'token', keys.whatsapp_token)} disabled={isSaving.whatsapp || !keys.whatsapp_token}>
              {isSaving.whatsapp ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Save className="w-4 h-4 mr-2" />}
              Salvar
            </Button>
          </CardFooter>
        </Card>

        {/* Bling Card */}
        <Card className="shadow-sm lg:col-span-2">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-emerald-500/10 flex items-center justify-center">
                  <Link2 className="w-5 h-5 text-emerald-600" />
                </div>
                <div>
                  <CardTitle>Bling ERP</CardTitle>
                  <CardDescription>Sincronização de Estoque e Notas Fiscais</CardDescription>
                </div>
              </div>
              <StatusBadge statusData={status.bling} />
            </div>
          </CardHeader>
          <CardContent>
            <div className="bg-muted/30 rounded-lg p-4 border border-border/50">
              <p className="text-sm text-muted-foreground mb-4">
                A integração com o Bling utiliza OAuth2. O token é gerenciado automaticamente pelo sistema após a autorização inicial.
              </p>
              <div className="flex items-center gap-4">
                <Button variant="outline" onClick={() => handleTest('bling')} disabled={isTesting.bling}>
                  {isTesting.bling ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <RefreshCw className="w-4 h-4 mr-2" />}
                  Testar Conexão Atual
                </Button>
                {status.bling?.ultimo_teste && (
                  <span className="text-xs text-muted-foreground">Último teste: {new Date(status.bling.ultimo_teste).toLocaleString('pt-BR')}</span>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}