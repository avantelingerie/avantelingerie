import React, { useState, useEffect } from 'react';
import { Users, Download, Search, ArrowUpDown, AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/button.jsx';
import { Input } from '@/components/ui/input.jsx';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx';
import { Pagination, PaginationContent, PaginationItem, PaginationNext, PaginationPrevious } from '@/components/ui/pagination.jsx';
import { toast } from 'sonner';
import { clientesService } from '@/services/clientesService.js';
import ClientesTable from '@/components/admin/ClientesTable.jsx';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert.jsx';

export default function ClientesPage() {
  const [clientes, setClientes] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [search, setSearch] = useState('');
  
  const [sort, setSort] = useState('-criado_em');

  const fetchClientesList = async (currentPage = 1) => {
    setIsLoading(true);
    setError(null);
    try {
      const res = await clientesService.getClientes(currentPage, 20, { search }, sort);
      setClientes(res.items || []);
      setTotalPages(res.totalPages || 1);
      setPage(res.page || 1);
    } catch (err) {
      console.error('Erro na página ClientesPage:', err);
      const msg = err?.response?.message || err?.message || 'Falha ao buscar dados';
      setError(`Erro ao carregar clientes: ${msg}. Consulte o console (F12) para detalhes técnicos.`);
      toast.error('Não foi possível carregar a lista de clientes.');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    const delayFn = setTimeout(() => fetchClientesList(1), 400);
    return () => clearTimeout(delayFn);
  }, [search, sort]);

  const handleExport = () => {
    clientesService.exportClientesCSV(clientes);
    toast.success('Exportação iniciada.');
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b pb-6">
        <div>
          <h1 className="text-3xl font-bold text-foreground flex items-center gap-3">
            <Users className="w-8 h-8 text-primary" />
            Clientes
          </h1>
          <p className="text-muted-foreground mt-1">Gerencie os clientes cadastrados na loja.</p>
        </div>
        <div className="flex items-center gap-3">
          <Button variant="outline" onClick={handleExport} disabled={isLoading || clientes.length === 0}>
            <Download className="w-4 h-4 mr-2" /> Exportar CSV
          </Button>
        </div>
      </div>

      <div className="flex flex-col md:flex-row gap-4 bg-card p-4 border rounded-xl shadow-sm">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input 
            placeholder="Buscar por nome, email ou CPF..." 
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9"
          />
        </div>
        <div className="w-full md:w-64 flex items-center gap-2">
          <ArrowUpDown className="w-4 h-4 text-muted-foreground shrink-0" />
          <Select value={sort} onValueChange={setSort}>
            <SelectTrigger><SelectValue placeholder="Ordenar por" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="-criado_em">Mais recentes primeiro</SelectItem>
              <SelectItem value="criado_em">Mais antigos primeiro</SelectItem>
              <SelectItem value="-total_compras">Maior volume de compras</SelectItem>
              <SelectItem value="total_compras">Menor volume de compras</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {error ? (
        <Alert variant="destructive" className="mb-6">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Erro</AlertTitle>
          <AlertDescription className="flex flex-col gap-3 items-start">
            <p>{error}</p>
            <Button variant="outline" size="sm" onClick={() => fetchClientesList(page)}>
              Tentar Novamente
            </Button>
          </AlertDescription>
        </Alert>
      ) : (
        <>
          <ClientesTable clientes={clientes} isLoading={isLoading} />

          {totalPages > 1 && (
            <div className="flex items-center justify-between pt-4">
              <span className="text-sm text-muted-foreground">Página {page} de {totalPages}</span>
              <Pagination>
                <PaginationContent>
                  <PaginationItem>
                    <PaginationPrevious 
                      onClick={() => page > 1 && fetchClientesList(page - 1)}
                      className={page === 1 ? 'pointer-events-none opacity-50' : 'cursor-pointer'}
                    />
                  </PaginationItem>
                  <PaginationItem>
                    <PaginationNext 
                      onClick={() => page < totalPages && fetchClientesList(page + 1)}
                      className={page === totalPages ? 'pointer-events-none opacity-50' : 'cursor-pointer'}
                    />
                  </PaginationItem>
                </PaginationContent>
              </Pagination>
            </div>
          )}
        </>
      )}
    </div>
  );
}