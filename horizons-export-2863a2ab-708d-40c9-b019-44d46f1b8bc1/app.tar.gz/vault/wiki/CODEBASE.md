# Codebase Map

This is a monorepo for an e-commerce platform with a Next.js frontend, Node.js/Express backend, and PocketBase database.

| Service | Purpose |
|---------|---------|
| `apps/web` | Next.js frontend (storefront + admin) |
| `apps/api` | Node.js/Express backend (integrations, business logic) |
| `apps/pocketbase` | PocketBase instance (database, auth, file storage) |

---

## apps/web

Next.js frontend with storefront and admin panel.

### Core hooks & utilities
- `apps/web/src/hooks/useAuth.js` — auth state (login/logout/register)
- `apps/web/src/hooks/useCart.js` — carrinho (add/remove/update, localStorage)
- `apps/web/src/lib/apiServerClient.js` — axios instance para chamadas ao backend Node.js
- `apps/web/src/utils/pocketbaseClient.js` — PocketBase client (auth, CRUD)
- `apps/web/src/utils/logger.js` — logging utility
- `apps/web/src/utils/blingTokenManager.js` — gerenciamento de token Bling

### Páginas (checkout & pedidos)
- `apps/web/src/pages/CartPage.jsx` — página do carrinho (upgrade B2B, cálculo de totais, etc.) (truncado)
- `apps/web/src/pages/Checkout.jsx` — checkout (endereço, método pagamento, finalizeOrder → `finalizeOrder()` do hook)
- `apps/web/src/pages/OrderConfirmation.jsx` — confirmação do pedido (busca `pedidos` e fallback `orders`; renderiza status e sugestões)
- `apps/web/src/components/CheckoutAddressForm.jsx` — formulário de endereço com máscara CEP
- `apps/web/src/components/CheckoutOrderSummary.jsx` — resumo do pedido no checkout (desconto PIX/progressivo)
- `apps/web/src/components/OrderSummary.jsx` — resumo do pedido (checkout UI com banner PIX)
- `apps/web/src/components/PixInfoBlock.jsx` — banner de elegibilidade PIX
- `apps/web/src/components/ProgressiveDiscountBar.jsx` — barra de progresso do desconto progressivo
- `apps/web/src/components/SmartShipping.jsx` — cálculo de frete via API Node (`/shipping/calculate`)
- `apps/web/src/components/CheckoutMicroOffer.jsx` — micro-oferta (busca produtos e adiciona ao carrinho)

### Serviços (PocketBase)
- `apps/web/src/services/clientesService.js` — CRUD/consulta de `users` e `enderecos` (inclui `getClientes` com sanitização de `sort`)
- `apps/web/src/services/produtosService.js` — listagem/CRUD de `products` e helpers (destaques/novidades)
- `apps/web/src/services/estoqueService.js` — listagem de `variacoes`, movimentações e sincronização com Bling (via API Node)
- `apps/web/src/services/descontosService.js` — configurações e gestão de cupons/faixas PIX/progressivo (seedTestData etc.)
- `apps/web/src/services/pedidosService.js` — listagem/criação/atualização de `pedidos` (inclui `generatePedidoNumber`)
- `apps/web/src/services/blingService.js` — frontend service que chama backend via apiServerClient (formatPedidoForBling, sendPedidoToBling)

### Páginas públicas (principais)
- `apps/web/src/pages/HomePage.jsx` — vitrine (fetch de produtos e testimonials)
- `apps/web/src/pages/ProductPage.jsx` — página do produto (variações, estoque, preços, PIX/progressivo)
- `apps/web/src/pages/CategoryPage.jsx` — vitrine por categoria (filtros + `sort` state)
- `apps/web/src/pages/LoginPage.jsx` — login/signup (coleção `users`)
- `apps/web/src/pages/MinhaContaPage.jsx` — painel do cliente (pedidos, perfil; tenta `pedidos` e fallback `orders`)
- `apps/web/src/pages/ComingSoonPage.jsx` — modo em breve (config via API Node)
- `apps/web/src/pages/ContactPage.jsx` — contato (cria `contact_messages`)
- `apps/web/src/pages/CentralDaClientePage.jsx` — central do cliente (políticas/FAQ)
- `apps/web/src/pages/RastreioPage.jsx` — rastreio (busca via API Node, fallback produtos)
- `apps/web/src/pages/MedidasPage.jsx` — guia de medidas (conteúdo estático)
- `apps/web/src/pages/QueroRevenderPage.jsx` — funil revendedora (B2B)
- `apps/web/src/pages/ResellerPortalPage.jsx` — portal revendedora (ativação, precificação, downloads; truncado)

### Admin (rotas/pages e componentes)
- `apps/web/src/pages/admin/AdminLogin.jsx` — `GET/POST` via UI: login em `/admin/login`
- `apps/web/src/components/admin/AdminLayout.jsx` — layout do admin + sidebar + badges (estoque crítico)
- `apps/web/src/pages/admin/DashboardPage.jsx` — dashboard (KPIs, gráficos, listas rápidas)
- `apps/web/src/pages/admin/ProdutosListagem.jsx` — listagem/CRUD de `products`
- `apps/web/src/pages/admin/ProdutoForm.jsx` — criação/edição de produto + imagens + variações
- `apps/web/src/pages/admin/CategoriasManager.jsx` — CRUD de `categorias`
- `apps/web/src/pages/admin/EstoqueListagem.jsx` — listagem de `variacoes` + filtros + modais
- `apps/web/src/pages/admin/ConfiguracoesEstoque.jsx` — configurações de estoque (limite alerta global)
- `apps/web/src/pages/admin/ConfiguracoesLoja.jsx` — configurações da loja + leads coming soon
- `apps/web/src/pages/admin/ConfiguracoesFrete.jsx` — CRUD de regras de frete via API Node
- `apps/web/src/pages/admin/DescontosPage.jsx` — abas: cupons, progressivo, PIX, boleto, relatório
- `apps/web/src/pages/admin/PedidosPage.jsx` — listagem de `pedidos` com filtros e export CSV
- `apps/web/src/pages/admin/NovoPedidoPage.jsx` — criação manual de pedido
- `apps/web/src/pages/admin/PedidoDetalhePage.jsx` — detalhe do pedido + update status + enviar para Bling
- `apps/web/src/pages/admin/ClientesPage.jsx` — listagem clientes + solicitações B2B + export CSV
- `apps/web/src/pages/admin/ClienteDetalhePage.jsx` — detalhe do cliente + endereços + pedidos + bloqueio
- `apps/web/src/pages/admin/IntegracoesList.jsx` — status e gerenciamento de chaves (Bling/Stripe/Melhor Envio/etc.)
- `apps/web/src/pages/admin/AnalyticsPage.jsx` — analytics admin (truncado)

Admin components (principais):
- `apps/web/src/components/admin/ClientesTable.jsx` — tabela clientes
- `apps/web/src/components/admin/ClienteDetalhes.jsx` — card dados cadastrais
- `apps/web/src/components/admin/ClienteDescontos.jsx` — card nível/desconto + modal
- `apps/web/src/components/admin/ClienteEnderecos.jsx` — lista e ações de endereços
- `apps/web/src/components/admin/ClientePedidos.jsx` — histórico de pedidos do cliente
- `apps/web/src/components/admin/AjusteDescontoModal.jsx` — modal ajuste nível desconto
- `apps/web/src/components/admin/EnderecoModal.jsx` — modal CRUD de endereços
- `apps/web/src/components/admin/PedidosTable.jsx` — tabela de pedidos
- `apps/web/src/components/admin/PedidoDetalhes.jsx` — dados do pedido (cliente/endereço)
- `apps/web/src/components/admin/PedidoItens.jsx` — itens do pedido
- `apps/web/src/components/admin/PedidoResumo.jsx` — resumo financeiro
- `apps/web/src/components/admin/PedidoHistorico.jsx` — histórico de status
- `apps/web/src/components/admin/NotificacoesPanel.jsx` — painel de notificações (polling `/notificacoes`)
- `apps/web/src/components/admin/MovimentacaoEstoqueModal.jsx` — modal movimentação estoque
- `apps/web/src/components/admin/HistoricoEstoqueModal.jsx` — modal histórico estoque
- `apps/web/src/components/admin/ImageUpload.jsx` — upload imagens (validação MIME e limite 5MB)
- `apps/web/src/components/admin/VariacoesTable.jsx` — geração/edição de variações
- `apps/web/src/components/admin/DescontoProgressivoTab.jsx` — faixas progressivas (varejo/revenda)
- `apps/web/src/components/admin/DescontoPIXTab.jsx` — configuração PIX
- `apps/web/src/components/admin/CuponsTab.jsx` — listagem cupons + filtros + paginação
- `apps/web/src/components/admin/CupomModal.jsx` — modal criação/edição cupom
- `apps/web/src/components/admin/RelatorioUsoTab.jsx` — relatório de uso + gráfico + export
- `apps/web/src/components/admin/DetalhesUsoModal.jsx` — detalhes de uso por período
- `apps/web/src/components/admin/BoletoConfigTab.jsx` — configuração boleto (Stripe)

Routes: (inferidas do `App.jsx` e componentes)
- Público: `/`, `/cart`, `/checkout`, `/order-confirmation/:orderId`, `/login`, `/account` (Minha Conta), `/pedidos`, `/contato`, `/rastreio`, `/central-da-cliente`, `/medidas`, `/quero-revender`, `/portal-revenda`, `/categoria/:categoryName`, `/produto/:id`, `/coming-soon/*` (via interceptor)
- Admin: `/admin/login`, `/admin`, `/admin/produtos`, `/admin/categorias`, `/admin/estoque`, `/admin/pedidos`, `/admin/pedidos/novo`, `/admin/pedidos/:id`, `/admin/clientes`, `/admin/clientes/:id`, `/admin/descontos`, `/admin/integracoes`, `/admin/analytics`, `/admin/configuracoes/loja`, `/admin/configuracoes/frete`, `/admin/configuracoes`

---

## apps/api

Node.js/Express backend for integrations and business logic.

---

## apps/pocketbase

PocketBase instance — database, auth, file storage.

### Migrations
- `apps/pocketbase/pb_migrations/1783955793_add_ncm_to_categorias.js` — adiciona coluna `ncm` (text, opcional) à coleção `categorias`

### Collections
- `categorias` — categorias de produtos (inclui campo `ncm`)
- `products` — produtos
- `variacoes` — variações de produtos
- `users` — clientes
- `enderecos` — endereços de clientes
- `pedidos` — pedidos
- `contact_messages` — mensagens de contato
- `cupons` — cupons de desconto
- `descontos_progressivos` — faixas de desconto progressivo
- `descontos_pix` — configuração PIX
- `descontos_boleto` — configuração boleto
- `notificacoes` — notificações admin
