#####
O app é um e-commerce de alto desempenho para a Avante/Mimo Lingerie, com experiência elegante e persuasiva, totalmente responsiva, vendendo para dois públicos (consumidor final e revendedoras) com regras automáticas de acesso e descontos. A plataforma usa Horizons com backend integrado (PocketBase), Stripe para pagamentos e (na fase 2) Melhor Envio para envio.

- Definiu a stack do projeto: Horizons + PocketBase (substituindo Supabase por incompatibilidade) + Stripe; Melhor Envio fica para fase 2.
- Modelou o banco no PocketBase com coleções equivalentes às tabelas planejadas: usuários (cliente/revendedora e nível), produtos (preços varejo/atacado, promoções, estoque, métricas), pedidos e leads.
- Implementou o fluxo de páginas do e-commerce: Home, Produto, Carrinho, Checkout, Confirmação, Categoria, FAQ, Guia de Tamanhos, Revendedora, Área Revendedora e Admin.
- Aplicou regra de segurança no PocketBase para destravar a “Gestão de Clientes”: ajustou `updateRule` da coleção `solicitacoes_revendedor` para permitir atualização apenas para usuários autenticados (`@request.auth.id != ""`).
- Garantiu que o campo `status` da coleção `solicitacoes_revendedor` tenha opções exatamente: `pendente`, `em_analise`, `aprovado`, `rejeitado`, `aprovado_automaticamente`.
- Criou uma rota GET de setup para aplicar/validar mudanças no schema via navegador (evitando necessidade de POST manual), com URL específica para acionar a correção.
##### 2026-07-13 15:17 UTC — "Crie uma coluna com o nome 'ncm' na coleção 'categorias' do PocketBase"
- Added optional `ncm` text field to `categorias` collection in PocketBase
- Verified field creation via schema inspection
- Edited/created: `apps/pocketbase/pb_migrations/1783955793_add_ncm_to_categorias.js`

##### 2026-07-14 01:25 UTC — "Corrija o arquivo blingService.js para usar apenas apiServerClient no frontend"
- Verified `blingService.js` already correctly imports only `apiServerClient` and contains `formatPedidoForBling()` and `sendPedidoToBling()` methods; no changes needed
- Edited/created: `apps/web/src/services/blingService.js` (verified, no edits required)
